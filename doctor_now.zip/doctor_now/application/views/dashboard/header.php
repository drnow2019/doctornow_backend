<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title><?= $title ?></title>

    <!-- Fontfaces CSS-->
    <link href="<?= base_url('assets/css/font-face.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/font-awesome-4.7/css/font-awesome.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/font-awesome-5/css/fontawesome-all.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/mdi-font/css/material-design-iconic-font.min.css')?>" rel="stylesheet" media="all">
    <link rel="icon" href="<?= base_url('assets/images/icon/appicon_2.png" type="image/png')?>" sizes="16x16">

    <!-- Bootstrap CSS-->
    <link href="<?= base_url('assets/vendor/bootstrap-4.1/bootstrap.min.css')?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?= base_url('assets/vendor/animsition/animsition.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/wow/animate.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/css-hamburgers/hamburgers.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/slick/slick.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/select2/select2.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('assets/vendor/perfect-scrollbar/perfect-scrollbar.css')?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?= base_url('assets/css/theme.css')?>" rel="stylesheet" media="all">

</head>

  <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="<?= base_url('assets/images/icon/logo.png')?>" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="tablinks  active">
                            <a href="index.html">
                                <i class="fas fa-home"></i>Dashboard</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="usermanagement.html">
                               <i class="fas fa-user"></i>User Management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="bookingmanagement.html"><i class="fas fa-sign-in-alt"></i>Booking Management</a>
                        </li>

                        <li class="tablinks">
                            <a href="doctorsmanagement.html"><i class="fas fa-stethoscope"></i>Doctor Specialty management</a>
                        </li>
                        
                        <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-child"></i>Promo code Management</a>
                             <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li><a href="promocodemanagement.html">Manage Promo Code</a></li>
                                <li><a href="specificpromocode.html">Specifc Promo Code</a></li>
                            </ul>
                        </li>
                        
                        
                        
                        <li class="tablinks">
                            <a href="#"><i class="fas fa-thermometer"></i>Medicine Delivery Management</a>
                        </li>
                        
                        
                        <li class="tablinks">
                            <a href="usernotification.html"><i class="fas fa-bell"></i>Notification Management </a>
                        </li>
                        
                        <!-- <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-bell"></i>Notification Management </a>
                             <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li><a href="usernotification.html">Users Notifications</a></li>
                                <li><a href="#">Doctors Notifications</a></li>
                            </ul>
                        </li> -->
                        
                        
                        
                        <li class="tablinks">
                            <a href="reportsmanagement.html"><i class="fas fa-chart-line"></i>Report Management </a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="transactionmanagement.html"><i class="fas fa-dollar-sign"></i>Transaction management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="staticcontentmanagement.html"><i class="fas fa-edit"></i>Static content Management </a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="livesupportmanagement.html"><i class="fas fa-phone-volume"></i>Live support management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="ratingsmanagement.html"><i class="fas fa-star"></i>Ratings Management </a>
                        </li>
                    
                    </ul>
                </div>
            </nav>
        </header>