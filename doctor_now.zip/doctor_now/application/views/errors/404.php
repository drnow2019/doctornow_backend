<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<style>
.error-template {padding: 40px 15px;text-align: center;}
.error-actions {margin-top:15px;margin-bottom:15px;}
.error-actions .btn { margin-right:10px; }
</style>


<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
    <div class="error-template">
	    <h1>Oops!</h1>
			<img src="<?=base_url('error/404.jpg')?>">
	    <h2>404 Not Found</h2>
	    <div class="error-details">
		Sorry, an error has occured, Requested page not found!<br>
		
	    </div>
	  
	</div>
    </div>
</div>