  <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="index.html">
                    <img src="<?= base_url('assets/images/icon/logo.png')?>" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                    
                        <li class="tablinks  active">
                            <a href="index.html">
                                <i class="fas fa-home"></i>Dashboard</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="usermanagement.html">
                               <i class="fas fa-user"></i>User Management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="bookingmanagement.html"><i class="fas fa-sign-in-alt"></i>Booking Management</a>
                        </li>

                        <li class="tablinks">
                            <a href="doctorsmanagement.html"><i class="fas fa-stethoscope"></i>Doctor Specialty management</a>
                        </li>
                        
                        <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-child"></i>Promo code Management</a>
                             <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li><a href="promocodemanagement.html">Manage Promo Code</a></li>
                                <li><a href="specificpromocode.html">Specifc Promo Code</a></li>
                            </ul>
                        </li>
                        
                        
                        
                        <li class="tablinks">
                            <a href="#"><i class="fas fa-thermometer"></i>Medicine Delivery Management</a>
                        </li>
                        
                        
                        <li class="tablinks">
                            <a href="usernotification.html"><i class="fas fa-bell"></i>Notification Management </a>
                        </li>
                        
                        <!-- <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-bell"></i>Notification Management </a>
                             <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li><a href="usernotification.html">Users Notifications</a></li>
                                <li><a href="#">Doctors Notifications</a></li>
                            </ul>
                        </li> -->
                        
                        
                        
                        <li class="tablinks">
                            <a href="reportsmanagement.html"><i class="fas fa-chart-line"></i>Report Management </a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="transactionmanagement.html"><i class="fas fa-dollar-sign"></i>Transaction management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="staticcontentmanagement.html"><i class="fas fa-edit"></i>Static content Management </a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="livesupportmanagement.html"><i class="fas fa-phone-volume"></i>Live support management</a>
                        </li>
                        
                        <li class="tablinks">
                            <a href="ratingsmanagement.html"><i class="fas fa-star"></i>Ratings Management </a>
                        </li>
                    
                    </ul>
                </nav>
            </div>
        </aside>