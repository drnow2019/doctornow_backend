<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="content-wrapper">
<link href="<?=base_url('assets/component-chosen.css') ?>" rel="stylesheet">
  <!-- BEGIN PAGE CONTAINER-->
  <div class="container-fluid">
    <!-- BEGIN PAGE HEADER-->   
    <div class="row-fluid">
      <div class="span12">
      </div>
    </div>
    <section class="content-header">
       <div class="row">
        <?php $CleintName = $this->my_model->fetchValue(USERS,'firstname',array('id'=>$id));?>
        <div class="col-md-6"><h4><span class="breadcornor"><i class="fa fa-users" aria-hidden="true"></i>  Personal Details-> <?= ucwords($CleintName)?> </span><img src="<?php echo base_url();?>assets/breadcornor.png" style="top: -2px;position:relative;" /></h4></div>
        <div class="col-md-6" style="text-align:right;">
        &nbsp;
        </div>
        </div>
      
    </section>

    <div class="tabbable tabbable-custom">
          <ul class="nav nav-tabs">
            <li ><a href="<?= base_url('admin/client/edit/'.$id)?>">Personal Details</a></li>
            <li class="active"><a href="javascript:;">Concerned With Experts</a></li>
             <li><a href="<?= base_url('admin/client/payment/'.$id) ?>">Payment History</a></li>
            </ul>

    <!-- END PAGE HEADER-->
    <!-- BEGIN PAGE CONTENT-->
    <div class="row-fluid box" style="padding:10px;">
      <div class="span12">
        <div class="loading" ><div class="content"><img src="<?php echo base_url('assets/images/loading.gif'); ?>"/></div></div>
      
      <div class="widget" id="form_wizard_1">
        <div class="widget-body form" style="color:#333;">
        <div class="row">
         

        <div class="col-md-12">

        <?php 
        $attributes = array('class' => 'form-horizontal', 'id' => 'myForm' );
         echo form_open_multipart('admin/client/editclient',$attributes); 
        ?>
        
          <div class="tab-content">
          <div class="tab-pane active" id="tab1">
         <br>
           <div class="row">
             <table class="table table-striped table-bordered">
               <thead>
               <tr>
                <th>S.No</th>
                 <th>Expert Name</th>
                 <th>Expert Mobile</th>
                 <th>Expert Email</th>
                 <th>Question </th>
                 <th>Date  </th>
                
                 
               </tr>
             </thead>
             <tbody>
              <?php 
               $sn=0;
              // echo "<pre>";
              //print_r($expert);die;
              if(!empty($client)){ 
              foreach($client as $values): 
                $sn++;
                
              $question_name = $this->my_model->fetchValue(EXPERTQUERY,'question',array('id'=>$values->question_id));
                
                ?>
              <tr>
              <td><?= $sn ?></td>
              <td><?= $values->firstname ?></td> 
              <td><?= $values->mobile ?></td> 
              <td><?= $values->emailid ?></td> 
              <td><?php echo substr($question_name,0,20)?><?php if(strlen($question_name)>'20'){?><span style="padding-left: 10px;padding-top: 5px;margin-top:8px;" ><button class="btn btn-xs btn-danger " value="    btn-xs" type="button" style="border-radius: 3px;font-size:10px;margin-top:20px" onclick="readmore('<?= $values->question_id ?>')">read more</button></span><?php } ?></td>  
               
             
              <td><?= date('d-m-Y',strtotime($values->create_date)) ?></td> 
            </tr>
          <?php  
            endforeach;
             }else{
           ?>
          <tr>
           <td ><center><b style="color: red;">No Record Available</b></center></td>
          </tr>
         <?php } ?>
             </tbody>
             </table>
             </div>
           </div>

          
                  
                  <img id="buttonreplacement" style="display: none;" src="<?php echo base_url('assets/images/preload.gif'); ?>" alt="loading...">

                
               </div>
            </div>
                      
            
      
          </div>
          </div>
          
          </div>
  
          </div>
          
          
       <?php echo form_close(); ?>
      </div>
      </div>
    </div>
    </div>
  <!-- END PAGE CONTENT-->
  </div>
</div>
</div>

<div id="formmodel" class="modal"></div>


<script>
  function readmore(id){
   //alert(id);
    $.ajax({
            type: 'POST',
            cache: false,
            url: '<?= base_url("admin/payment/readmore")?>',
            data:'id='+id,
            
            success: function (html) { 
              //alert(html);
             $("#formmodel").html(html);
             $("#formmodel").modal('show');
            
         }
          });
  }
</script>
