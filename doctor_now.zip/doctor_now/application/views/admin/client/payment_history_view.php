<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="content-wrapper">
<link href="<?=base_url('assets/component-chosen.css') ?>" rel="stylesheet">
  <!-- BEGIN PAGE CONTAINER-->
  <div class="container-fluid">
    <!-- BEGIN PAGE HEADER-->   
    <div class="row-fluid">
      <div class="span12">
      </div>
    </div>
    <section class="content-header">
       <div class="row">
        <div class="col-md-6"><h4><span class="breadcornor"><i class="fa fa-users" aria-hidden="true"></i>  Personal Details-> <?= ucwords($CleintName) ?> </span><img src="<?php echo base_url();?>assets/breadcornor.png" style="top: -2px;position:relative;" /></h4></div>
        <div class="col-md-6" style="text-align:right;">
        &nbsp;
        </div>
        </div>
      
    </section>

    <div class="tabbable tabbable-custom">
          <ul class="nav nav-tabs">
            <li ><a href="<?= base_url('admin/client/edit/'.$id)?>">Personal Details</a></li>
            <li><a href="<?= base_url('admin/client/cleintconcerned/'.$id)?>">Concerned With Experts</a></li>
             <li class="active"><a href="javascript:;">Payment History</a></li>
            </ul>

    <!-- END PAGE HEADER-->
    <!-- BEGIN PAGE CONTENT-->
    <div class="row-fluid box" style="padding:10px;">
      <div class="span12">
        <div class="loading" ><div class="content"><img src="<?php echo base_url('assets/images/loading.gif'); ?>"/></div></div>
      
      <div class="widget" id="form_wizard_1">
        <div class="widget-body form" style="color:#333;">
        <div class="row">
         

        <div class="col-md-12">

        <?php 
        $attributes = array('class' => 'form-horizontal', 'id' => 'myForm' );
         echo form_open_multipart('admin/client/editclient',$attributes); 
        ?>
        
          <div class="tab-content">
          <div class="tab-pane active" id="tab1">
         <br>
           <div class="row">
             <table class="table table-striped table-bordered">
               <thead>
               <tr>
                <th>S.No</th>
                 <th>Expert Name</th>
                 <th>Question </th>
                 <th>Total Amount </th>
                 <th>Currency </th>
                 <th>Payment Method </th>
                 <th>Transaction Id </th>
                 <th>Payment Date </th>
                 
               </tr>
             </thead>
             <tbody>
              <?php 
               $sn=0;
               $sum= 0;
              if(!empty($clientPayment)){ 
              foreach($clientPayment as $values): 
                $sn++;
                
               $question= $this->my_model->fetchValue(EXPERTQUERY,'question',array('id'=>$values->question_id));
                $sum= $sum+$values->amount;
                ?>
              <tr>
              <td><?= $sn ?></td>
              <td><?= $expertname ?></td> 
              <td><?php echo substr($question,0,20)?><?php if(strlen($question)>'20'){?><span style="padding-left: 10px;padding-top: 5px;margin-top:8px;" ><button class="btn btn-xs btn-danger " value="    btn-xs" type="button" style="border-radius: 3px;font-size:10px;margin-top:20px" onclick="readmore('<?= $values->question_id?>')">read more</button></span><?php } ?></td>  
              <td> <?= '$'.$values->amount ?></td> 
              <td><?= $values->currency ?></td> 
              <td><?= $values->payment_method ?></td> 
              <td><?= $values->transaction_id ?></td> 
              <td><?= date('d-m-Y',strtotime($values->pay_date)) ?></td> 
            </tr>
          <?php  
            endforeach;
             }else{
           ?>
          <tr>
           <td ><center><b style="color: red;">No Record Available</b></center></td>
          </tr>
          <?php } if(!empty($clientPayment)):?>
          <br>

           <tr>
             <td style="margin-bottom: 2px" colspan="8"><b>Total Earning Amount:&nbsp;&nbsp;</b><span class="badge bg-red"><?= '$' . number_format($sum, 2); ?></span></td>
           </tr>
         <?php endif; ?>
             </tbody>
             </table>
             </div>
           </div>

          
                  
                  <img id="buttonreplacement" style="display: none;" src="<?php echo base_url('assets/images/preload.gif'); ?>" alt="loading...">

                
               </div>
            </div>
                      
            
      
          </div>
          </div>
          
          </div>
  
          </div>
          
          
       <?php echo form_close(); ?>
      </div>
      </div>
    </div>
    </div>
  <!-- END PAGE CONTENT-->
  </div>
</div>
</div>

<div id="formmodel" class="modal"></div>


<script>
  function readmore(id){
   //alert(id);
    $.ajax({
            type: 'POST',
            cache: false,
            url: '<?= base_url("admin/payment/readmore")?>',
            data:'id='+id,
            
            success: function (html) { 
              //alert(html);
             $("#formmodel").html(html);
             $("#formmodel").modal('show');
            
         }
          });
  }
</script>
