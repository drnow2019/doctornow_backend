<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

<div class="content-wrapper">
<link href="<?=base_url('assets/component-chosen.css') ?>" rel="stylesheet">
  <!-- BEGIN PAGE CONTAINER-->
  <div class="container-fluid">
    <!-- BEGIN PAGE HEADER-->   
    <div class="row-fluid">
      <div class="span12">
      </div>
    </div>
    <section class="content-header">
       <div class="row">
        <div class="col-md-6"><h4><span class="breadcornor"><i class="fa fa-users" aria-hidden="true"></i>  Personal Details-> <?= ucwords($client[0]->firstname.' '.$expert[0]->lastname)?> </span><img src="<?php echo base_url();?>assets/breadcornor.png" style="top: -2px;position:relative;" /></h4></div>
        <div class="col-md-6" style="text-align:right;">
        &nbsp;
        </div>
        </div>
      
    </section>

    <div class="tabbable tabbable-custom">
          <ul class="nav nav-tabs">
            <li class="active"><a href="javascript:;">Personal Details</a></li>
            <li><a href="<?= base_url('admin/client/cleintconcerned/'.$client[0]->id)?>">Concerned With Experts</a></li>
             <li><a href="<?= base_url('admin/client/payment/'.$client[0]->id)?>">Payment History</a></li>
            </ul>

    <!-- END PAGE HEADER-->
    <!-- BEGIN PAGE CONTENT-->
    <div class="row-fluid box" style="padding:10px;">
      <div class="span12">
        <div class="loading" ><div class="content"><img src="<?php echo base_url('assets/images/loading.gif'); ?>"/></div></div>
      
      <div class="widget" id="form_wizard_1">
        <div class="widget-body form" style="color:#333;">
        <div class="row">
          <div class="col-md-1"></div>

        <div class="col-md-7">

        <?php 
        $attributes = array('class' => 'form-horizontal', 'id' => 'myForm' );
         echo form_open_multipart('admin/client/editclient',$attributes); 
        ?>
        
          <div class="tab-content">
          <div class="tab-pane active" id="tab1">
        
            <div class="row">
            <div class="col-md-3">
              <input type="hidden" class="form-control" name="clientid" value="<?=$client[0]->id?>">
              <label class="control-label">First Name<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
                  
                  <input type="text" class="form-control" name="first_name"  placeholder="First Name"  value="<?php echo  $client[0]->firstname?>"  data-validation="required">
                  <br />
                  <?php //echo form_error('first_name','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>

            <div class="row">
            <div class="col-md-3">
              <label class="control-label">Last Name<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
                  
                  <input type="text" class="form-control" name="last_name"  placeholder="Last Name"  value="<?php echo  $client[0]->lastname?>"  data-validation="required">
                  <br />
                  <?php //echo form_error('last_name','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>
              
               <div class="row">
            <div class="col-md-3">
              <label class="control-label">Mobile <font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
              <div class="controls">
                <input type="text" class="form-control"  placeholder="Phone Number" name="mobile"   maxlength="20"  value="<?php echo  $client[0]->mobile?>"   maxlength="10"  onkeypress="return numbersonly(event)" >
                <br />
                <?php //echo form_error('mobile','<span class="error" style="color:red;">'); ?>
              </div>
              </div>
            </div>

             <div class="row">
            <div class="col-md-3">
              <label class="control-label">Email<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
                  
                  <input type="text" class="form-control" name="email"  placeholder="Email"  value="<?php echo  $client[0]->emailid?>"  data-validation="required" readonly>
                  <br />
                  <?php //echo form_error('email','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>

              <div class="row">
            <div class="col-md-3">
              <label class="control-label">Country<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
            <select name="country" id="country" class="form-control form-control-chosen" data-placeholder="Please select..."   onchange="getstate()">
            <option value="">Select Country</option>
           <?php foreach($country as $values){ ?>
            <option value="<?= $values->id; ?>"  <?php if($client[0]->country_id==$values->id){echo"selected";}?>><?= $values->name; ?></option>
          <?php } ?>
          </select>
                  <br />
                  <?php //echo form_error('email','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>

             <div class="row">
            <div class="col-md-3">
              <label class="control-label">State<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
             <select name="state" id="tt" class="form-control form-control-chosen" data-placeholder="Please select..."  >
             <option>Select State..</option>
            <?php foreach($state as $values){ ?>
            <option value="<?= $values->id; ?>"  <?php if($client[0]->state_id==$values->id){echo"selected";}?>><?= $values->name; ?></option>
          <?php } ?>
          
          </select>
          <span id="state"></span>
                  <br />
                  <?php //echo form_error('email','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>


              <div class="row">
            <div class="col-md-3">
              <label class="control-label">City<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
                  
                  <input type="text" class="form-control" name="city"  placeholder="City"  value="<?php echo  $client[0]->city?>"  data-validation="required">
                  <br />
                  <?php //echo form_error('email','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>


              <div class="row">
            <div class="col-md-3">
              <label class="control-label">Pincode<font color="#FF0000">*</font> :</label>
              </div>
              <div class="col-md-9">
                <div class="controls">
                  
                  <input type="text" class="form-control" name="pincode"  placeholder="Pincode"  value="<?php echo  $client[0]->pin_code?>"  data-validation="required" >
                  <br />
                  <?php //echo form_error('email','<span class="error" style="color:red;">'); ?>
                </div>
                </div>
            </div>
           
            <div>&nbsp;</div>
            <div class="control-group">
              <label class="control-label">&nbsp;</label>
                <div class="controls">
                  <a href="<?= base_url('admin/client')?>" class="btn btn-default"><i class="icon-angle-left"></i> Back </a>
                  
                  <button type="submit" class="btn btn-success" name="save" id="smt" > Submit <i class="icon-ok"></i></button>
                  
                  <img id="buttonreplacement" style="display: none;" src="<?php echo base_url('assets/images/preload.gif'); ?>" alt="loading...">

                
               </div>
            </div>
                      
            
      
          </div>
          </div>
          
          </div>
  
          </div>
          
          
       <?php echo form_close(); ?>
      </div>
      </div>
    </div>
    </div>
  <!-- END PAGE CONTENT-->
  </div>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/chosen/1.8.6/chosen.jquery.min.js"></script>
<script>
  $('.form-control-chosen').chosen({

});
</script>

<script>
  function getstate()
  {
    
    var cont_id = $("#country").val();
     if(cont_id)
      {
     
         $.ajax({
            type: 'POST',
            url: '<?= base_url('admin/client/getstate')?>',
            data:'cont_id='+cont_id,
            success: function (responsedata) { 
            if(responsedata!="") 
            {
              $("#state").html(responsedata);
             // alert(responsedata);
              $("#tt").hide();

            }
           
            }
          });
       

      }
  }
</script>


