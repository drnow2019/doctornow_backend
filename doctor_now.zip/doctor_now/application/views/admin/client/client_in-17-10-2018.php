<?php
 //print_r($phase);die;
    $n=0;
    if(!empty($event)):
		foreach($event as $values):
		$n++;
		?>
    <tr id="<?=$values->id?>">
	<td><?=$n?></td>
	<?php $roleid= $this->session->userdata('roleid1');
     if($roleid[4]['edit_id']==2){?>
	<td><a href="<?= base_url('admin/client/edit/'.$values->id)?>"><?=ucfirst($values->firstname).' '.ucfirst($values->lastname)?></a></td>
     <?php } else{?>
	<td><?=ucfirst($values->firstname).' '.ucfirst($values->lastname)?></td>
     <?php } ?>
	<td><?= $values->emailid?></td>
	<td><?=$values->mobile ?></td>
	

	<td style="width:100px; text-align:center;">		
	   <button onclick="return rowstatus('<?=USERS?>','id','<?=$values->id?>','status','<?=$values->status?>');"  title="Change Status" <?php if($values->status == '1' ){ ?> class="btn btn-success btn-xs"> <?php echo "Approved "; } else { ?> class="btn btn-primary btn-xs"><?php  echo "Unapproved"; } ?>
		</button> 
	</td>
	<td style="text-align:center;">
		<div class="btn-group">
			<button type="button" class="btn btn-danger btn-xs maction dropdown-toggle" data-toggle="dropdown">Action</button>
			<button type="button" class="btn btn-danger btn-xs dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
				<span class="caret"></span>
				<span class="sr-only">Toggle Dropdown</span>
			</button>
			<ul class="dropdown-menu" role="menu">
				<?php
				 $roleid= $this->session->userdata('roleid1');
                 if($roleid[4]['del_id']==3){?>
				<li>
					<a href="javascript:void(null);" onclick="return deleterow('<?=strrev(USERS)?>','id','<?=$values->id?>');"><i class="fa fa-trash" aria-hidden="true" class="btn"></i>Delete</a>
				</li>
			<?php } ?>
				
			</ul>
		</div>	
	</td>

	
 </tr>
	<?php
		endforeach;
	else:

	?>
<tr>
	<td ><center><b style="color: red;">No Record Available</b></center></td>
</tr>
<?php
	endif;
	echo $this->ajax_pagination->create_links(); 
?>



