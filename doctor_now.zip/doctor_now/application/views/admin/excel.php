<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<div class="content-wrapper">
  <!-- BEGIN PAGE CONTAINER-->
  <div class="container-fluid">

    <!-- BEGIN PAGE CONTENT-->
    <div class="row-fluid box" style="padding:10px;">
	
	
	<div class="row">
        <div class="col-md-6"><h4><span class="breadcornor"><i class="fa fa-users" aria-hidden="true"></i>IMPORT AND EXPORT EXCEL </span><img src="<?php echo base_url('assets/breadcornor.png');?>" style="top: -2px;position:relative;" /></h4></div>
		<div class="col-md-4"></div>
        <div class="col-md-2" style="text-align:right;margin-bottom: 15px;">
        &nbsp;
       <span> <?php 
      $attributes = array('class' => 'form-horizontal', 'id' => 'myForm');
      echo form_open_multipart('lead/export_csvv',$attributes); 
     ?> 
    <?php 
               $data = array(
                      'name'    => 'Download as Excel',
                      'id'      => 'smtt',
                      'type'    => 'submit',
                      'class'   => 'btn btn-block btn-success btn-flat pull-right',
                      'content' => '<i class="fa fa-download" aria-hidden="true"></i> Download as Excel'
                    );
              // if($this->session->userdata('isp_user') =="1")
                 echo form_button($data);
                 echo form_close();
               ?></span>
        </div>
        </div>
	
	
	
      <div class="span12">
        <div class="loading"><div class="content">
		<img src="<?php echo base_url('assets/images/loading.gif'); ?>"/></div></div>
      
      <div class="widget" id="form_wizard_1">
	    <div class="msg" id="msg"><?php if($this->session->flashdata('msg')){ echo $this->session->flashdata('msg');}?></div>
        <div class="widget-body form" style="color:#333;">
		
        <div class="row">
        <div class="col-md-12">
		 
            <div class="panel panel-primary">
			 <div class="panel-heading"><span>Import Data</span>
		           <div class="panel-heading" style="float: right;">
   

     </div>
     
       

               </div>
               
                <div class="panel-body form-horizontal">
                  <form method="POST" action="<?=base_url('admin/import/upload')?>"  enctype="multipart/form-data">
                   		<br><br>
                      <div class="col-md-1"></div>
					<div class="form-group">
						<label class="col-md-2">Upload File:</label>
                        <div class="col-md-5">
                            <input type="file" class="form-control" name="upload" data-validation="required">
                        </div>
						
                        <div class="col-md-2">
                          <button type="submit" class="btn btn-success btn-block">SUBMIT</button>
                        </div>
                    </div>
					  </form>
					
                </div>
            </div>   

			
        </div> <!-- / panel preview -->
       
          
          </div>
        
          
          
       <?php echo form_close(); ?>
      </div>
      </div>
    </div>
    </div>
  <!-- END PAGE CONTENT-->
  </div>
</div>
</div>


