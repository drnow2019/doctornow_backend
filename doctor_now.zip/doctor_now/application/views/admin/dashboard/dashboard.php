<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Admin Dashboard Doctor Now</title>

    <!-- Fontfaces CSS-->
    <link href="<?= base_url('css/font-face.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/font-awesome-4.7/css/font-awesome.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/font-awesome-5/css/fontawesome-all.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/mdi-font/css/material-design-iconic-font.min.css')?>" rel="stylesheet" media="all">
	<link rel="icon" href="<?= base_url('images/icon/appicon_2.png" type="image/png')?>" sizes="16x16">

    <!-- Bootstrap CSS-->
    <link href="<?= base_url('vendor/bootstrap-4.1/bootstrap.min.css')?>" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="<?= base_url('vendor/animsition/animsition.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/wow/animate.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/css-hamburgers/hamburgers.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/slick/slick.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/select2/select2.min.css')?>" rel="stylesheet" media="all">
    <link href="<?= base_url('vendor/perfect-scrollbar/perfect-scrollbar.css')?>" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="<?= base_url('css/theme.css')?>" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="images/icon/logo.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li class="tablinks  active">
                            <a href="index.html">
                                <i class="fas fa-home"></i>Dashboard</a>
                        </li>
						
						<li class="tablinks">
                            <a href="usermanagement.html">
                               <i class="fas fa-user"></i>User Management</a>
                        </li>
						
						<li class="tablinks">
							<a href="bookingmanagement.html"><i class="fas fa-sign-in-alt"></i>Booking Management</a>
						</li>

						<li class="tablinks">
                            <a href="doctorsmanagement.html"><i class="fas fa-stethoscope"></i>Doctor Specialty management</a>
                        </li>
						
						<li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-child"></i>Promo code Management</a>
							 <ul class="list-unstyled navbar__sub-list js-sub-list">
								<li><a href="promocodemanagement.html">Manage Promo Code</a></li>
								<li><a href="specificpromocode.html">Specifc Promo Code</a></li>
                            </ul>
                        </li>
						
						
						
						<li class="tablinks">
                            <a href="#"><i class="fas fa-thermometer"></i>Medicine Delivery Management</a>
                        </li>
						
						
						<li class="tablinks">
                            <a href="usernotification.html"><i class="fas fa-bell"></i>Notification Management </a>
                        </li>
						
						<!-- <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-bell"></i>Notification Management </a>
							 <ul class="list-unstyled navbar__sub-list js-sub-list">
								<li><a href="usernotification.html">Users Notifications</a></li>
								<li><a href="#">Doctors Notifications</a></li>
                            </ul>
                        </li> -->
						
						
						
						<li class="tablinks">
                            <a href="reportsmanagement.html"><i class="fas fa-chart-line"></i>Report Management </a>
                        </li>
						
						<li class="tablinks">
                            <a href="transactionmanagement.html"><i class="fas fa-dollar-sign"></i>Transaction management</a>
                        </li>
						
						<li class="tablinks">
                            <a href="staticcontentmanagement.html"><i class="fas fa-edit"></i>Static content Management </a>
                        </li>
						
						<li class="tablinks">
                            <a href="livesupportmanagement.html"><i class="fas fa-phone-volume"></i>Live support management</a>
                        </li>
						
						<li class="tablinks">
                            <a href="ratingsmanagement.html"><i class="fas fa-star"></i>Ratings Management </a>
                        </li>
					
                    </ul>
                </div>
            </nav>
        </header>
        <!-- END HEADER MOBILE-->

        <!-- MENU SIDEBAR-->
        <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="index.html">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
					
						<li class="tablinks  active">
                            <a href="index.html">
                                <i class="fas fa-home"></i>Dashboard</a>
                        </li>
						
						<li class="tablinks">
                            <a href="usermanagement.html">
                               <i class="fas fa-user"></i>User Management</a>
                        </li>
						
						<li class="tablinks">
							<a href="bookingmanagement.html"><i class="fas fa-sign-in-alt"></i>Booking Management</a>
						</li>

						<li class="tablinks">
                            <a href="doctorsmanagement.html"><i class="fas fa-stethoscope"></i>Doctor Specialty management</a>
                        </li>
						
						<li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-child"></i>Promo code Management</a>
							 <ul class="list-unstyled navbar__sub-list js-sub-list">
								<li><a href="promocodemanagement.html">Manage Promo Code</a></li>
								<li><a href="specificpromocode.html">Specifc Promo Code</a></li>
                            </ul>
                        </li>
						
						
						
						<li class="tablinks">
                            <a href="#"><i class="fas fa-thermometer"></i>Medicine Delivery Management</a>
                        </li>
						
						
						<li class="tablinks">
                            <a href="usernotification.html"><i class="fas fa-bell"></i>Notification Management </a>
                        </li>
						
						<!-- <li class="has-sub tablinks">
                             <a href="#" class="js-arrow"><i class="fas fa-bell"></i>Notification Management </a>
							 <ul class="list-unstyled navbar__sub-list js-sub-list">
								<li><a href="usernotification.html">Users Notifications</a></li>
								<li><a href="#">Doctors Notifications</a></li>
                            </ul>
                        </li> -->
						
						
						
						<li class="tablinks">
                            <a href="reportsmanagement.html"><i class="fas fa-chart-line"></i>Report Management </a>
                        </li>
						
						<li class="tablinks">
                            <a href="transactionmanagement.html"><i class="fas fa-dollar-sign"></i>Transaction management</a>
                        </li>
						
						<li class="tablinks">
                            <a href="staticcontentmanagement.html"><i class="fas fa-edit"></i>Static content Management </a>
                        </li>
						
						<li class="tablinks">
                            <a href="livesupportmanagement.html"><i class="fas fa-phone-volume"></i>Live support management</a>
                        </li>
						
						<li class="tablinks">
                            <a href="ratingsmanagement.html"><i class="fas fa-star"></i>Ratings Management </a>
                        </li>
					
                    </ul>
                </nav>
            </div>
        </aside>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                <input class="au-input au-input--xl" type="text" name="search" placeholder="Search for datas &amp; reports..." />
                                <button class="au-btn--submit" type="submit">
                                    <i class="zmdi zmdi-search"></i>
                                </button>
                            </form>
                            <div class="header-button">
                                <div class="noti-wrap">
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-comment-more"></i>
                                        <span class="quantity">1</span>
                                        <div class="mess-dropdown js-dropdown">
                                            <div class="mess__title">
                                                <p>You have 2 news message</p>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-06.jpg" alt="Michelle Moreno" />
                                                </div>
                                                <div class="content">
                                                    <h6>Michelle Moreno</h6>
                                                    <p>Have sent a photo</p>
                                                    <span class="time">3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="mess__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-04.jpg" alt="Diane Myers" />
                                                </div>
                                                <div class="content">
                                                    <h6>Diane Myers</h6>
                                                    <p>You are now connected on message</p>
                                                    <span class="time">Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="mess__footer">
                                                <a href="#">View all messages</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-email"></i>
                                        <span class="quantity">1</span>
                                        <div class="email-dropdown js-dropdown">
                                            <div class="email__title">
                                                <p>You have 3 New Emails</p>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-06.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, 3 min ago</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-05.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, Yesterday</span>
                                                </div>
                                            </div>
                                            <div class="email__item">
                                                <div class="image img-cir img-40">
                                                    <img src="images/icon/avatar-04.jpg" alt="Cynthia Harvey" />
                                                </div>
                                                <div class="content">
                                                    <p>Meeting about new dashboard...</p>
                                                    <span>Cynthia Harvey, April 12,,2018</span>
                                                </div>
                                            </div>
                                            <div class="email__footer">
                                                <a href="#">See all emails</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="noti__item js-item-menu">
                                        <i class="zmdi zmdi-notifications"></i>
                                        <span class="quantity">3</span>
                                        <div class="notifi-dropdown js-dropdown">
                                            <div class="notifi__title">
                                                <p>You have 3 Notifications</p>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c1 img-cir img-40">
                                                    <i class="zmdi zmdi-email-open"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a email notification</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c2 img-cir img-40">
                                                    <i class="zmdi zmdi-account-box"></i>
                                                </div>
                                                <div class="content">
                                                    <p>Your account has been blocked</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__item">
                                                <div class="bg-c3 img-cir img-40">
                                                    <i class="zmdi zmdi-file-text"></i>
                                                </div>
                                                <div class="content">
                                                    <p>You got a new file</p>
                                                    <span class="date">April 12, 2018 06:50</span>
                                                </div>
                                            </div>
                                            <div class="notifi__footer">
                                                <a href="#">All notifications</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="account-wrap">
                                    <div class="account-item clearfix js-item-menu">
                                        <div class="image">
                                            <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                        </div>
                                        <div class="content">
                                            <a class="js-acc-btn" href="#">john doe</a>
                                        </div>
                                        <div class="account-dropdown js-dropdown">
                                            <div class="info clearfix">
                                                <div class="image">
                                                    <a href="#">
                                                        <img src="images/icon/avatar-01.jpg" alt="John Doe" />
                                                    </a>
                                                </div>
                                                <div class="content">
                                                    <h5 class="name">
                                                        <a href="#">john doe</a>
                                                    </h5>
                                                    <span class="email">johndoe@example.com</span>
                                                </div>
                                            </div>
                                            
                                            <div class="account-dropdown__footer">
                                                <a href="#">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
			
			<div id="testmgnt" class="tabcontent" style="display: block;"> 
			<div class="main-content">
					<div class="section__content section__content--p30">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="overview-wrap">
										<h2 class="title-1">Dashboard</h2>
										<!-- <button class="au-btn au-btn-icon au-btn--blue">
											<i class="zmdi zmdi-plus"></i>Add New Grade</button> -->
									</div>
								</div>
								<div class="col-md-12">
								
								<!-- This Module Consist of Managing Nanny Activities -->
								
								<div class="nobgarhome tabdatabga tabdashcontent" id="Gradeclass" style="display: block;">
									<div class="paneldatadrnow">
									<div class="icomgntadro">
									<i class="far fa-user"></i>
									<p>Users</p>
									</div>
										<div class="single-chart">
											<svg viewBox="0 0 36 36" class="circular-chart orange">
											  <path class="circle-bg" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <path class="circle" stroke-dasharray="90, 100" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <text x="18" y="20.35" class="percentage">200</text>
											</svg>
											
										</div>
									</div>
									
									
									<div class="paneldatadrnow">
									<div class="icomgntadro">
									<i class="fas fa-stethoscope"></i>
									<p>Doctor requests</p>
									</div>
										<div class="single-chart">
											<svg viewBox="0 0 36 36" class="circular-chart orange">
											  <path class="circle-bg" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <path class="circle" stroke-dasharray="90, 100" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <text x="18" y="20.35" class="percentage">1000</text>
											</svg>
											
										</div>
									</div>
									
									
									<div class="paneldatadrnow">
									<div class="icomgntadro">
									<i class="fas fa-users"></i>
									<p>New Bookings </p>
									</div>
										<div class="single-chart">
											<svg viewBox="0 0 36 36" class="circular-chart orange">
											  <path class="circle-bg" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <path class="circle" stroke-dasharray="90, 100" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <text x="18" y="20.35" class="percentage">700+</text>
											</svg>
											
										</div>
									</div>
									
									
									<div class="paneldatadrnow">
									<div class="icomgntadro">
									<i class="fas fa-pills"></i>
									<p>Medicine Delivery</p>
									</div>
										<div class="single-chart">
											<svg viewBox="0 0 36 36" class="circular-chart orange">
											  <path class="circle-bg" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <path class="circle" stroke-dasharray="90, 100" d="M18 2.0845
												  a 15.9155 15.9155 0 0 1 0 31.831
												  a 15.9155 15.9155 0 0 1 0 -31.831"></path>
											  <text x="18" y="20.35" class="percentage">900</text>
											</svg>
											
										</div>
									</div>
  
  
                                <div class="mainsd">
								<div class="">
							   <div class="au-card m-b-30">
                                    <div class="au-card-inner">
                                        <h3 class="title-2 m-b-40">Total earnings </h3>
                                        <canvas id="lineChart"></canvas>
                                    </div>
                                </div>
								</div>
                            </div>
  
								</div>
								
								<div class="tabdatabga tabdashcontent" id="classgradedname" style="display:none;">
								<h1 class="lefthn">Classnames</h1>
								
								<div class="tabdashlinks backbtnarw" onclick="openDash(event, 'Gradeclass')">Back Button</div>
								
								<div class="classlistspart">
								   <ul>
								   <li class="tabactslinks" onclick="openActivity(event, 'classgradeone')">Classroom 1</li>
								   <li class="tabactslinks" onclick="openActivity(event, 'classgradetwo')">Classroom 2</li>
								   <li class="tabactslinks" onclick="openActivity(event, 'classgradethree')">Classroom 3</li>
								   <li class="tabactslinks" onclick="openActivity(event, 'classgradefour')">Classroom 4</li>
								   </ul>
								</div>
								
								<div class="actcenters gradecricle">
								
								<div class="tabdatabga tabactscontent" id="classgradeone" style="display:block;">
								<ul>
									<li data-toggle="modal" data-target="#mediumModal4">
									<div class="innercrc">
									<p><img src="images/icon/audio.png" class="shownow"><img src="images/icon/audiohover.png" class="showhovernw">
									<span>Audio</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal5">
									<div class="innercrc">
									<p><img src="images/icon/imgvideo.png" class="shownow"><img src="images/icon/imgvideohover.png" class="showhovernw">
									<span>Photo/Video</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal6">
									<div class="innercrc"><p><img src="images/icon/meal.png" class="shownow"><img src="images/icon/mealhover.png" class="showhovernw">
									<span>Meal</span></p></div>
									</li>
									
									
									
									<li data-toggle="modal" data-target="#mediumModal7">
									<div class="innercrc">
									<p><img src="images/icon/nap.png" class="shownow"><img src="images/icon/naphover.png" class="showhovernw">
									<span>Nap</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal8">
									<div class="innercrc">
									<p><img src="images/icon/toilet.png" class="shownow"><img src="images/icon/toilethover.png" class="showhovernw">
									<span>Toilet</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal9">
									<div class="innercrc">
									<p><img src="images/icon/activity.png" class="shownow"><img src="images/icon/activityhover.png" class="showhovernw">
									<span>Activities</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal10">
									<div class="innercrc">
									<p><img src="images/icon/report.png" class="shownow"><img src="images/icon/reporthover.png" class="showhovernw">
									<span>Report</span></p>
									</div>
									</li>
									
								</ul>
								</div>
								
								<div class="tabdatabga tabactscontent" id="classgradetwo" style="display:none;">
								<ul>
									<li data-toggle="modal" data-target="#mediumModal4">
									<div class="innercrc">
									<p><img src="images/icon/audio.png" class="shownow"><img src="images/icon/audiohover.png" class="showhovernw">
									<span>Audio</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal5">
									<div class="innercrc">
									<p><img src="images/icon/imgvideo.png" class="shownow"><img src="images/icon/imgvideohover.png" class="showhovernw">
									<span>Photo/Video</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal6">
									<div class="innercrc"><p><img src="images/icon/meal.png" class="shownow"><img src="images/icon/mealhover.png" class="showhovernw">
									<span>Meal</span></p></div>
									</li>
									
									
									
									<li data-toggle="modal" data-target="#mediumModal7">
									<div class="innercrc">
									<p><img src="images/icon/nap.png" class="shownow"><img src="images/icon/naphover.png" class="showhovernw">
									<span>Nap</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal8">
									<div class="innercrc">
									<p><img src="images/icon/toilet.png" class="shownow"><img src="images/icon/toilethover.png" class="showhovernw">
									<span>Toilet</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal9">
									<div class="innercrc">
									<p><img src="images/icon/activity.png" class="shownow"><img src="images/icon/activityhover.png" class="showhovernw">
									<span>Activities</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal10">
									<div class="innercrc">
									<p><img src="images/icon/report.png" class="shownow"><img src="images/icon/reporthover.png" class="showhovernw">
									<span>Report</span></p>
									</div>
									</li>
									
								</ul>
								</div>
								
								<div class="tabdatabga tabactscontent" id="classgradethree" style="display:none;">
								<ul>
									<li data-toggle="modal" data-target="#mediumModal4">
									<div class="innercrc">
									<p><img src="images/icon/audio.png" class="shownow"><img src="images/icon/audiohover.png" class="showhovernw">
									<span>Audio</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal5">
									<div class="innercrc">
									<p><img src="images/icon/imgvideo.png" class="shownow"><img src="images/icon/imgvideohover.png" class="showhovernw">
									<span>Photo/Video</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal6">
									<div class="innercrc"><p><img src="images/icon/meal.png" class="shownow"><img src="images/icon/mealhover.png" class="showhovernw">
									<span>Meal</span></p></div>
									</li>
									
									
									
									<li data-toggle="modal" data-target="#mediumModal7">
									<div class="innercrc">
									<p><img src="images/icon/nap.png" class="shownow"><img src="images/icon/naphover.png" class="showhovernw">
									<span>Nap</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal8">
									<div class="innercrc">
									<p><img src="images/icon/toilet.png" class="shownow"><img src="images/icon/toilethover.png" class="showhovernw">
									<span>Toilet</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal9">
									<div class="innercrc">
									<p><img src="images/icon/activity.png" class="shownow"><img src="images/icon/activityhover.png" class="showhovernw">
									<span>Activities</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal10">
									<div class="innercrc">
									<p><img src="images/icon/report.png" class="shownow"><img src="images/icon/reporthover.png" class="showhovernw">
									<span>Report</span></p>
									</div>
									</li>
									
								</ul>
								</div>
								
								<div class="tabdatabga tabactscontent" id="classgradefour" style="display:none;">
								<ul>
									<li data-toggle="modal" data-target="#mediumModal4">
									<div class="innercrc">
									<p><img src="images/icon/audio.png" class="shownow"><img src="images/icon/audiohover.png" class="showhovernw">
									<span>Audio</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal5">
									<div class="innercrc">
									<p><img src="images/icon/imgvideo.png" class="shownow"><img src="images/icon/imgvideohover.png" class="showhovernw">
									<span>Photo/Video</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal6">
									<div class="innercrc"><p><img src="images/icon/meal.png" class="shownow"><img src="images/icon/mealhover.png" class="showhovernw">
									<span>Meal</span></p></div>
									</li>
									
									
									
									<li data-toggle="modal" data-target="#mediumModal7">
									<div class="innercrc">
									<p><img src="images/icon/nap.png" class="shownow"><img src="images/icon/naphover.png" class="showhovernw">
									<span>Nap</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal8">
									<div class="innercrc">
									<p><img src="images/icon/toilet.png" class="shownow"><img src="images/icon/toilethover.png" class="showhovernw">
									<span>Toilet</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal9">
									<div class="innercrc">
									<p><img src="images/icon/activity.png" class="shownow"><img src="images/icon/activityhover.png" class="showhovernw">
									<span>Activities</span></p>
									</div>
									</li>
									
									<li data-toggle="modal" data-target="#mediumModal10">
									<div class="innercrc">
									<p><img src="images/icon/report.png" class="shownow"><img src="images/icon/reporthover.png" class="showhovernw">
									<span>Report</span></p>
									</div>
									</li>
									
								</ul>
								</div>
								
								
								</div>
								
								</div>
								
								
								</div>
							</div>
						</div>
							 
					</div>
				</div>
			</div>
			
			
			<div id="livelectmgnt" class="tabcontent" style="display: none;">
			<div class="main-content">
					<div class="section__content section__content--p30">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="overview-wrap">
										<h2 class="title-1">Test Management</h2>
										<button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#mediumModal">
											<i class="zmdi zmdi-plus"></i>Add Classrooms</button>
									</div>
									<div class="col-md-12 tabdatabga">
									<div class="">
                                <!-- DATA TABLE-->
										<div class="table-responsive m-b-40">
											<table class="table table-borderless table-data3">
												<thead>
													<tr>
														<th>S No.</th>
														<th>Classroom name</th>
														<th>Classroom number</th>
														<th>Number of Children</th>
														<th>Number of Nannies</th>
														<th>Edit Info</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													
												</tbody>
											</table>
										</div>
                                <!-- END DATA TABLE-->
									</div>
							  
									</div>
								</div>
							</div>
						</div>
							  
					</div>
				</div>
				
				
			</div>
			
			<div id="coursemgnt" class="tabcontent" style="display: none;">
				<div class="main-content">
					<div class="section__content section__content--p30">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="overview-wrap">
										<h2 class="title-1">Add Classrooms</h2>
										<button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#mediumModal">
											<i class="zmdi zmdi-plus"></i>Add Classrooms</button>
									</div>
									<div class="col-md-12 tabdatabga">
									<div class="">
                                <!-- DATA TABLE-->
										<div class="table-responsive m-b-40">
											<table class="table table-borderless table-data3">
												<thead>
													<tr>
														<th>S No.</th>
														<th>Classroom name</th>
														<th>Classroom number</th>
														<th>Number of Children</th>
														<th>Number of Nannies</th>
														<th>Edit Info</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													<tr>
														<td>1</td>
														<td>Alex</td>
														<td>23</td>
														<td>33</td>
														<td>4</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													
												</tbody>
											</table>
										</div>
                                <!-- END DATA TABLE-->
									</div>
							  
									</div>
								</div>
							</div>
						</div>
							  
					</div>
				</div>
			</div>
			
			<div id="subscrimgnt" class="tabcontent" style="display: none;">
				<div class="main-content">
					<div class="section__content section__content--p30">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="overview-wrap">
										<h2 class="title-1">Add Nannies</h2>
										<button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#mediumModal2">
											<i class="zmdi zmdi-plus"></i>Add New Nannies</button>
									</div>
									
									<div class="col-md-12 tabdatabga">
									<div class="">
                                <!-- DATA TABLE-->
										<div class="table-responsive m-b-40">
											<table class="table table-borderless table-data3">
												<thead>
													<tr>
														<th>S No.</th>
														<th>Name</th>
														<th>Sirname</th>
														<th>Username</th>
														<th>Password</th>
														<th>Edit</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>1</td>
														<td>Myranda</td>
														<td>Patrick</td>
														<td>Patrick</td>
														<td>Patrick</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													
													<tr>
														<td>1</td>
														<td>Myranda</td>
														<td>Patrick</td>
														<td>Patrick</td>
														<td>Patrick</td>
														<td>
															<div class="table-data-feature"> 
															<button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
																<i class="zmdi zmdi-edit"></i>
															</button>
															<button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
																<i class="zmdi zmdi-delete"></i>
															</button>
															</div>
														</td>
													</tr>
													
												</tbody>
											</table>
										</div>
                                <!-- END DATA TABLE-->
									</div>
							  
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div id="paymgnt" class="tabcontent" style="display: none;">
				<div class="main-content">
					<div class="section__content section__content--p30">
						<div class="container-fluid">
							<div class="row">
								<div class="col-md-12">
									<div class="overview-wrap">
										<h2 class="title-1">Add Children</h2>
										<button class="au-btn au-btn-icon au-btn--blue" data-toggle="modal" data-target="#mediumModal3">
											<i class="zmdi zmdi-plus"></i>Add New Children</button>
									</div>
									<div class="col-md-12 tabdatabga">
									<div class="">
                                <!-- DATA TABLE-->
										<div class="table-responsive m-b-40">
											<table class="table table-borderless table-data3">
												<thead>
													<tr>
														<th>Name</th>
														<th>SirName</th>
														<th>Age</th>
														<th>Father</th>
														<th>Parent Email</th>
														<th>Parents Phone Number</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>Alex</td>
														<td>Patrick</td>
														<td>23</td>
														<td>Robin Patrick</td>
														<td>robin@yahoomail.com</td>
														<td>0616 3098766</td>
													</tr>
													<tr>
														<td>Alex</td>
														<td>Patrick</td>
														<td>23</td>
														<td>Robin Patrick</td>
														<td>robin@yahoomail.com</td>
														<td>0616 3098766</td>
													</tr>
													<tr>
														<td>Alex</td>
														<td>Patrick</td>
														<td>23</td>
														<td>Robin Patrick</td>
														<td>robin@yahoomail.com</td>
														<td>0616 3098766</td>
													</tr>
													
													
												</tbody>
											</table>
										</div>
                                <!-- END DATA TABLE-->
									</div>
							  
									</div>
									
								</div>
							</div>
						</div>
							  
					</div>
				</div>
			</div>
			
			
			<div id="notifymgnt" class="tabcontent" style="display: none;">
				<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Ask for support</h2>
										
									</div>
							<div class="col-md-12 tabdatabga">
							
									<div id="accordion">
										  <div class="card">
											<div class="card-header" id="headingOne">
											  <h5 class="mb-0">
												<button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
												  What is the aim of this use-case is to define the meals to be served ?
												  <i class="fas fa-plus"></i>
												  <i class="fas fa-minus"></i>
												</button>
											  </h5>
											</div>

											<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
											  <div class="card-body">
												The aim of this use-case is to define the meals to be served to the children during the week. The input shall be done by grades. The
												meals shall be associated to all the children of the referred grade and shall be visible from each child profile. The meals to be defined
												are: breakfast, morning snack, lunch and afternoon snack. To be
												filled in a weekly basis.
											  </div>
											</div>
										  </div>
										  <div class="card">
											<div class="card-header" id="headingTwo">
											  <h5 class="mb-0">
												<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
												  Is The meals shall be associated to all the children of the referred grade ?
												   <i class="fas fa-plus"></i>
												  <i class="fas fa-minus"></i>
												</button>
											  </h5>
											</div>
											<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
											  <div class="card-body">
												 Yes The meals shall be associated to all the children of the referred grade and shall be visible from each child profile. 
											  </div>
											</div>
										  </div>
										  <div class="card">
											<div class="card-header" id="headingThree">
											  <h5 class="mb-0">
												<button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
												  What Are The Meals to be Defined ?
												   <i class="fas fa-plus"></i>
												  <i class="fas fa-minus"></i>
												</button>
											  </h5>
											</div>
											<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
											  <div class="card-body">
												The meals to be defined are: breakfast, morning snack, lunch and afternoon snack. To be filled in a weekly basis.
											  </div>
											</div>
										  </div>
									</div>
								
								<div class="supportadmin">
									<h4> Have Any Questions ? Let us know !</h4>
									<div class="card">
									 <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
									 <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="textarea-input" class=" form-control-label">Write Your Query HereFdeine</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <textarea name="textarea-input" id="textarea-input" rows="9" placeholder="Content..." class="form-control"></textarea>
                                                </div>
                                            </div>
									 </form>
									</div>
								</div>
								</div>
							</div>
						</div>
				</div>
			</div>
			
			<div id="banrmgnt" class="tabcontent" style="display: none;">
			<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Banner Management</h2>
										
									</div>
			
			</div>
			</div>
			</div>
			</div>
			
			
			<div id="forumngnt" class="tabcontent" style="display: none;">
			<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Forum Management</h2>
										
									</div>
			
			</div>
			</div>
			</div>
			</div>
			
			
			
			<div id="staticontentmgnt" class="tabcontent" style="display: none;">
			<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Static Content  Management</h2>
										
									</div>
			
			</div>
			</div>
			</div>
			</div>
			
			
			<div id="ordermgnt" class="tabcontent" style="display: none;">
			<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Order  Management</h2>
										
									</div>
			
			</div>
			</div>
			</div>
			</div>
			
			<div id="reportsmgnt" class="tabcontent" style="display: none;">
			<div class="main-content">
						<div class="section__content section__content--p30">
							<div class="container-fluid">
							<div class="overview-wrap">
										<h2 class="title-1">Reports  Management</h2>
										
									</div>
			
			</div>
			</div>
			</div>
			</div>
			
			
			
			
			
		
			<div class="row">
				<div class="col-md-12">
					<div class="copyright">
						<p>Copyright © 2018 ASEC. All rights reserved. <a href="#">Mobulous</a>.</p>
					</div>
				</div>
			</div>
        </div>
		
    </div>
	
	<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Add Number Of Children</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    <div class="card-body card-block">
                                       <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Classroom name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Classroom number</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="select" id="select" class="form-control">
                                                        <option value="0">Please select</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
														<option value="3">4</option>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Number of Children</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Number of Nannies</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
                                        </form>

                                            
                                            
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="mediumModal2" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Add Nannies</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    <div class="card-body card-block">
                                       <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Enter Your Name" class="form-control">
                                                </div>
                                            </div>
											
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Surname</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Enter Your Surname" class="form-control">
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Username</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Enter Your Username" class="form-control">
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="password-input" class=" form-control-label">Password</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="password" id="password-input" name="password-input" placeholder="Enter Your Password" class="form-control">
                                                </div>
                                            </div>
                                        </form>

                                            
                                            
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			
			<div class="modal fade" id="mediumModal3" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Add Children</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    <div class="card-body card-block">
                                       <form action="" method="post" enctype="multipart/form-data" class="form-horizontal">
                                            <div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Name and </label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Surname</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Age (birth date)</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Profile photo (optional)</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="file" id="file-input" name="file-input" class="form-control-file">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Father Name</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Mother Name and Surname</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Surname</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="select" class=" form-control-label">Classroom number</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <select name="select" id="select" class="form-control">
                                                        <option value="0">Please select</option>
                                                        <option value="1">1</option>
                                                        <option value="2">2</option>
                                                        <option value="3">3</option>
														<option value="3">4</option>
                                                    </select>
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Number of Children</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
											
											<div class="row form-group">
                                                <div class="col col-md-3">
                                                    <label for="text-input" class=" form-control-label">Number of Nannies</label>
                                                </div>
                                                <div class="col-12 col-md-9">
                                                    <input type="text" id="text-input" name="text-input" placeholder="Text" class="form-control">
                                                    
                                                </div>
                                            </div>
                                        </form>

                                            
                                            
                                    </div>
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
	<!-- Audio Uploads 4-->
	
			<div class="modal fade" id="mediumModal4" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Upload Audio</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			
			<div class="modal fade" id="mediumModal5" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Upload Photo/Video</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="mediumModal6" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Children Meal Duration</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			
			<div class="modal fade" id="mediumModal7" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Children Nap Duration</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="mediumModal8" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Toilet</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="mediumModal9" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Activities</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			
			<div class="modal fade" id="mediumModal10" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-lg" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="mediumModalLabel">Report</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="card">
                                   
                                    
                                    <div class="card-footer">
                                        <button type="submit" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dot-circle-o"></i> Submit
                                        </button>
                                        <button type="reset" class="btn btn-danger btn-sm">
                                            <i class="fa fa-ban"></i> Reset
                                        </button>
                                    </div>
                                </div>
						</div>
						
					</div>
				</div>
			</div>
			

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>
	<script src="js/monami.js"></script>

</body>

</html>
<!-- end document-->
