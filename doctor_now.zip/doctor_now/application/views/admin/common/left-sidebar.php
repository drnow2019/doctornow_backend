
<div class="wrapper">
<?php $this->load->view("admin/common/topbar"); ?>
<?php $this->load->view("admin/common/leftmenu"); ?>
</div><!-- modal -->

