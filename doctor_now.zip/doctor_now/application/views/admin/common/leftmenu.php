 <?php $roleid= $this->session->userdata('roleid1');



 ?>

 <!-- Left side column. contains the logo and sidebar -->

      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->

        <section class="sidebar">

          <!-- Sidebar user panel -->

          <div class="user-panel">

            <div class="pull-left image">

              <img src="<?=base_url('assets/new/dist/img/user2-160x160.jpg')?>" class="img-circle" alt="User Image">

            </div>

            <div class="pull-left info">

              <p style="font-size: 16px;"><?=COMPANYNAME?></p>

              <a href="#"><i class="fa fa-circle text-success"></i> Online </a>

            </div>

            <small class="label pull-right label-success" style="color:#153359 !important; background:#fff !important; top:30px; position:relative;">v 1.0</small>

          </div>

          <!-- search form -->

           <ul class="sidebar-menu">

          

          <?php if(array_key_exists(1,$roleid)){ ?>

            <li class=" treeview <?php if(current_url()==base_url('admin/dashboard')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/dashboard')?>">

                <img src="<?=base_url('assets/web/img/dashboard.png')?>">&nbsp; <span>DASHBOARD</span></a>             

            </li>

           <?php } if(array_key_exists(12,$roleid)){?>

             <li class=" treeview <?php if(current_url()==base_url('admin/staff')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/staff')?>">

                <img src="<?=base_url('assets/web/img/user.png')?>">&nbsp; <span>STAFF</span></a>             

            </li>

        <?php } ?>

          



        <li class="treeview <?php if(current_url()==base_url('admin/approvedexpert') || current_url()==base_url('admin/unapprovedexpert')){ echo 'active'; } ?>" >

        <a href="#">

          <img src="<?=base_url('assets/web/img/tyre-expert.png')?>">&nbsp; <span>EXPERT </span>

          <i class="fa fa-angle-left pull-right"></i>

        </a>

        <ul class=" treeview-menu ">

        

        <?php if(array_key_exists(2,$roleid)){ ?>

          <li class="treeview">

            <a href="<?=base_url('admin/approvedexpert')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Approved Expert</span> </a>

          </li>

        <?php } if(array_key_exists(3,$roleid)){ ?>

          <li class="treeview">

            <a href="<?=base_url('admin/unapprovedexpert')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Unapproved Expert</span> </a>

          </li>

        <?php } ?>

          </ul>

      </li>



     <?php if(array_key_exists(4,$roleid)){ ?>

       <li class=" treeview <?php if(current_url()==base_url('admin/client')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/client')?>">

                <img src="<?=base_url('assets/web/img/support.png')?>">&nbsp; <span>CLIENT</span></a>             

            </li>

       <?php } if(array_key_exists(5,$roleid)){?>

          



             <li class=" treeview <?php if(current_url()==base_url('admin/subject')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/subject')?>">

                <img src="<?=base_url('assets/web/img/language.png')?>">&nbsp; <span>MANAGE SUBJECT</span></a>             

            </li>

          <?php } if(array_key_exists(6,$roleid)){?>



             <li class=" treeview <?php if(current_url()==base_url('admin/expertise')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/expertise')?>">

                <img src="<?=base_url('assets/web/img/specialist-user.png')?>">&nbsp; <span>MANAGE EXPERTISE</span></a>             

            </li>

     <?php } if(array_key_exists(7,$roleid)){?>

             <li class=" treeview <?php if(current_url()==base_url('admin/topics')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/topics')?>">

                <img src="<?=base_url('assets/web/img/focus.png')?>">&nbsp; <span>MANAGE TOPICS</span></a>             

            </li>

          <?php } if(array_key_exists(8,$roleid)){?>



              <li class=" treeview <?php if(current_url()==base_url('admin/managefunction')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/managefunction')?>">

                <img src="<?=base_url('assets/web/img/monitor.png')?>">&nbsp; <span>MANAGE FUNCTION</span></a>             

            </li>

         <?php } if(array_key_exists(9,$roleid)){?>



        <li class=" treeview <?php if(current_url()==base_url('admin/expertquery')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/expertquery')?>">

                <img src="<?=base_url('assets/web/img/question-mark.png')?>">&nbsp; <span>ASK QUESTION</span></a>             

            </li> 

        <?php } ?>

        <li class=" treeview <?php if(current_url()==base_url('admin/expertquestion')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/expertquestion')?>">

                <img src="<?=base_url('assets/web/img/question-mark.png')?>">&nbsp; <span>CONNECT TO EXPERT  </span></a>             

            </li>



            <!--  <li class="treeview <?php if(current_url()==base_url('admin/expertquery') || current_url()==base_url('admin/expertquestion') || current_url()==base_url('admin/calldetail')){ echo 'active'; } ?>" >

        <a href="#">

          <span class="fa fa-phone"></span>&nbsp; <span>MANAGE QUERY </span>

          <i class="fa fa-angle-left pull-right"></i>

        </a>

        <ul class=" treeview-menu ">

        

          <li class="treeview ">

            <a href="<?=base_url('admin/expertquestion')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Expert Question</span> </a>

          </li>



          <li class="treeview">

            <a href="<?=base_url('admin/expertquery')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Ask Question</span> </a>

          </li>



           <li class="treeview">

            <a href="<?=base_url('admin/calldetail')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Call Detail</span> </a>

          </li>

          </ul>

      </li> -->



      <li class="treeview <?php if(current_url()==base_url('admin/completedcalls') || current_url()==base_url('admin/schedulecalls')){ echo 'active'; } ?>" >

        <a href="#">

          <img src="<?=base_url('assets/web/img/tyre-expert.png')?>">&nbsp; <span>MANAGE CALLS </span>

          <i class="fa fa-angle-left pull-right"></i>

        </a>

        <ul class=" treeview-menu ">

        

        <?php if(array_key_exists(13,$roleid)){ ?>

          <li class="treeview">

            <a href="<?=base_url('admin/schedulecalls')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Opened calls</span> </a>

          </li>

        <?php } if(array_key_exists(14,$roleid)){ ?>

          <li class="treeview">

            <a href="<?=base_url('admin/completedcalls')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Closed Calls</span> </a>

          </li>

        <?php } ?>

          </ul>

      </li>





<li class=" treeview <?php if(current_url()==base_url('admin/paymentrequest')){ echo 'active'; } ?>" >

<a href="<?=base_url('admin/paymentrequest')?>">

<img src="<?=base_url('assets/web/img/client.png')?>">&nbsp; <span>PAYMENT REQUEST</span></a>             

</li> 	  

	  

   

<li class=" treeview <?php if(current_url()==base_url('admin/payment')){ echo 'active'; } ?>" >

<a href="<?=base_url('admin/payment')?>">

<img src="<?=base_url('assets/web/img/client.png')?>">&nbsp; <span>PAYMENT</span></a>             

</li> 



<!-- <li class=" treeview <?php if(current_url()==base_url('admin/feedback')){ echo 'active'; } ?>" >

<a href="<?=base_url('admin/feedback')?>">

<img src="<?=base_url('assets/web/img/survey.png')?>">&nbsp; <span>FEEDBACK</span></a>             

</li>  -->





 



 <li class="treeview <?php if(current_url()==base_url('admin/contactus') || current_url()==base_url('admin/newsletter')){ echo 'active'; } ?>" >

        <a href="#">

          <img src="<?=base_url('assets/web/img/tyre-expert.png')?>">&nbsp; <span>ENQUIRY </span>

          <i class="fa fa-angle-left pull-right"></i>

        </a>

        <ul class=" treeview-menu ">

        

       

          <li class="treeview">

            <a href="<?=base_url('admin/contactus')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Contact Us</span> </a>

          </li>

       

          <li class="treeview">

            <a href="<?=base_url('admin/newsletter')?>"><img src="<?=base_url('assets/web/img/play.png')?>">&nbsp; <span>Newsletter </span> </a>

          </li>

        

          </ul>

      </li>

      
      <li class=" treeview <?php if(current_url()==base_url('admin/designation')){ echo 'active'; } ?>" >
<a href="<?=base_url('admin/designation')?>">
<img src="<?=base_url('assets/web/img/client.png')?>">&nbsp; <span>MANAGE DESIGNATION</span></a>             
</li> 

			<?php  if(array_key_exists(11,$roleid)){?>

			<li class=" treeview <?php if(current_url()==base_url('admin/admin/changepassword')){ echo 'active'; } ?>" >

              <a href="<?=base_url('admin/admin/changepassword')?>">

                <img src="<?=base_url('assets/web/img/key.png')?>">&nbsp; <span>CHANGE PASSWORD</span></a>             

            </li>

			<?php } ?>





            <li class=" treeview" >

              <a href="<?=base_url('admin/admin/logout')?>">

                <img src="<?=base_url('assets/web/img/logout.png')?>">&nbsp; <span>LOGOUT</span></a>             

            </li>







      </ul>

	

  </section>

  <!-- /.sidebar -->

</aside>

