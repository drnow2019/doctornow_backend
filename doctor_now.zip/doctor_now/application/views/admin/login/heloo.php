<?php 
echo "hello"; ?>