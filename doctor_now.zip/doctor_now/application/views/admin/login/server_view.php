<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!DOCTYPE html>
 <html lang="en"> <!--<![endif]-->
<!-- BEGIN HEAD -->
<head>
  <meta charset="utf-8" />
  <title><?php echo $title; ?></title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta content="" name="description" />
  <meta content="" name="author" />

  <script language="javascript" type="text/javascript" src="<?php echo base_url("assets/js/index_validations.js"); ?>"></script>
  

<!--new design start-->  

<link rel="stylesheet" href="<?php echo base_url();?>assets/new/bootstrap/css/bootstrap.min.css">
<!-- Font Awesome -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
<!-- Theme style -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/new/dist/css/AdminLTE.min.css">
<!-- iCheck -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/new/plugins/iCheck/square/blue.css">


<!--new design end-->    
  
</head>
<!-- END HEAD -->
<!-- BEGIN BODY -->
<body class="hold-transition login-page" style="background:#153359;">
<!--<div class="login-header"><div class="center"><br><br><br></div></div>-->
<!-- BEGIN LOGIN -->

<div class="login-box" id="login" style="margin-bottom:1%;">
      <div style="background:url(<?php echo base_url();?>assets/images/headerbg.jpg); margin-bottom:0px; text-align:center; padding:30px 0; color:#fff;">
        <a href="index.php" style="color:#fff;"><b style="font-size:24px;">Choose Server</b></a>
      </div><!-- /.login-logo -->
      <?php
      $attributes = array('class' => 'form-vertical no-padding no-margin','id'=>'loginform' );
      echo form_open('admin/manageServer', $attributes); ?>
      <div class="login-box-body">
        <div class="msg"><?php if($this->session->flashdata('msg')){ echo $this->session->flashdata('msg');}?></div>

        <h4 style="color:#000;">Select Server :</h4>
          <br />
          <div class="form-group has-feedback" style="text-align: center;">
            <?php 
            if($server):
              $i = 0;
              
              foreach($server as $value):
                $checked = FALSE;
                $i ++;
                if($i == 1)
                  $checked = TRUE;

                $data = array(
                        'name'          => 'server',
                        'value'         => $value->id,
                        'checked'       => $checked,
                        'style'         => 'margin:10px',
                        'data-validation' => 'required'
                );

                echo $value->server_name.' '.form_radio($data).'&nbsp;&nbsp;&nbsp;&nbsp;';
              endforeach;
            endif;
            ?>          
          </div>
          <br />

          <div class="row">
         <!-- /.col -->           
            <div class="col-xs-12">
               <input style="background-color: #ff5a92; color:#fff; font-weight:bold;" type="submit" id="login-btn" class="btn btn-block login-btn" value="Submit" />
            </div><!-- /.col -->
          </div>

        <!-- /.social-auth-links -->

      </div><!-- /.login-box-body -->
       <?php echo form_close(); ?>
    </div>


  <!-- END LOGIN -->
  <!-- BEGIN COPYRIGHT -->
  <div id="login-copyright" style="color:#fff;font-size: 14px; text-align:center;">
 
  </div>
  <!-- END COPYRIGHT -->
  <!-- BEGIN JAVASCRIPTS -->
  <!-- jQuery 2.1.4 -->
    <script src="<?php echo base_url();?>assets/new/plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.5 -->
    <script src="<?php echo base_url();?>assets/new/bootstrap/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url();?>assets/new/plugins/iCheck/icheck.min.js"></script>
    <script src="<?php echo base_url("assets/js/scripts.js"); ?>"></script>
   
    <script>
      $(function () {
        $('input').iCheck({
          checkboxClass: 'icheckbox_square-blue',
          radioClass: 'iradio_square-blue',
          increaseArea: '20%' // optional
        });
      });
    </script>

  <?php // unset($_SESSION["invalid"]); ?>
  <!-- END JAVASCRIPTS -->
</body>
<script src="<?php echo base_url();?>assets/js/jquery.form-validator.min.js"></script>
  <script>

  $.validate({
    form : '#loginform',
    validateHiddenInputs : true,
    onSuccess : function($form) {
      
    //  $('#smt').hide();
      //$('#buttonreplacement').show(); 
    }
   
  });
</script>

<!-- END BODY -->
</html>