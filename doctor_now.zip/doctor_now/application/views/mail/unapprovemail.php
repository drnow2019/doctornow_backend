<?php 
	$pstyle = 'color:#000;text-align:left;font-family:Arial; line-height:1.6;';
 ?>

<p style="<?=$pstyle?>"> Dear <?php echo ucfirst($firstname); ?></p>
<p style="<?=$pstyle?>"> We regret to inform you that your profile has been rejected by the admin. If you have any question feel free to ask us.</p>

<p style="<?=$pstyle?>">Thanks for Choosing INSIGHT MONK!</p>

<p style="<?=$pstyle?>">Sincerely<br/>INSIGHT MONK</p>