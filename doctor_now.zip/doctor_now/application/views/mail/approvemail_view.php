<?php 
	$pstyle = 'color:#000;text-align:left;font-family:Arial; line-height:1.6;';
 ?>

<p style="<?=$pstyle?>"> Dear <?php echo ucfirst($firstname); ?></p>
<p style="<?=$pstyle?>">  We are glad to inform you that after successfully reviewing the application your profile has been accepted. Now you can log in and complete your profile using this link.<a href="http://www.insightmonk.com:4500/experts/login">Click Here</a></p>

<p style="<?=$pstyle?>">Thanks for Choosing INSIGHT MONK!</p>

<p style="<?=$pstyle?>">Sincerely<br/>INSIGHT MONK</p>