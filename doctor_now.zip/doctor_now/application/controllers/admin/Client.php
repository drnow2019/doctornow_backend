<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/////====	START LEAD CONTROLLERS CLASS   =======///////
class Client extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		
	    $this->load->model('my_model');
		$this->load->model('com_model');
	   	$this->perPage = 10;
		//$test = admin::addlead();
	} 
	   
	public function index()
	{ 
	///echo $leadtype;
		$this->load->library('Ajax_pagination');
		$tables = 'md_frontuser';
		$data = array();
		$cond = "id > 0 and user_type=1";
		$keywords   = $this->input->get('keywords');
        $sortBy 	 = $this->input->get('sortBy');
        $perPage 	 = $this->input->get('perpage');
        $activePage  = $this->input->get('activePage');

   
       
      $page = $this->input->get('page');
        if(!$page)
            $offset = 0;
        else
            $offset = $page; 

        if($perPage)
			$this->perPage = $perPage;

	
		if($keywords){
			
		$cond .= " AND (concat(firstname, ' ', lastname,emailid,mobile) LIKE '%".$keywords."%' OR firstname LIKE '%".$keywords."%' OR lastname LIKE '%".$keywords."%' OR emailid LIKE '%".$keywords."%' OR mobile LIKE '%".$keywords."%' ) ";
		}
		$fields = "*";
        $totalRec = $this->com_model->cuntrows($tables,"id",$cond);
        $config['target']      = '#postList';
        $config['base_url']    = base_url('client/ajaxPaginationData');
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $this->perPage;
		$config['colspan']     = 9;
        $config['link_func']   = 'searchFilter';
        $config['activePage']  = $activePage;

        $this->ajax_pagination->initialize($config);

	   	$conditions['start'] = $offset;
	   	$conditions['limit'] = $this->perPage;  
		$data['event'] = $this->com_model->getRows($tables,$fields,$cond,$conditions);
	
		//echo $this->db->last_query();die;
	 	$data['title'] = COMPANYNAME.' | Manage Client';
		$this->load->view('admin/common/header',$data); 
 		$this->load->view('admin/common/left-sidebar');
		$this->load->view('admin/client/client_view');
		$this->footer();
	}

	function ajaxPaginationData()
	{
		$this->load->library('Ajax_pagination');
	   		
        $conditions = array();
        $tables = 'md_frontuser';
        //calc offset number
        $page = $this->input->get('page');
        if(!$page)
            $offset = 0;
        else
            $offset = $page;
        
		$keywords   = $this->input->get('keywords');
        $perPage 	= $this->input->get('perpage');
        $activePage = $this->input->get('activePage');
        $cond       = " id > 0 and user_type=1";
        
		  if($keywords){
			
				$cond .= " AND (concat(firstname, ' ', lastname,emailid,mobile) LIKE '%".$keywords."%' OR firstname LIKE '%".$keywords."%' OR lastname LIKE '%".$keywords."%' OR emailid LIKE '%".$keywords."%' OR mobile LIKE '%".$keywords."%' ) ";

		  }
		$fields = "*";
		$totalRec = $this->com_model->cuntrows($tables,"id",$cond);
		$config['target']      = '#postList';
        $config['base_url']    = base_url().'client/ajaxPaginationData';
        $config['total_rows']  = $totalRec;
        $config['per_page']    = $perPage;
        $config['link_func']   = 'searchFilter';
        $config['activePage']  = $activePage;
		$config['colspan']     = 9;
        $this->ajax_pagination->initialize($config);
        
        $conditions['start'] = $offset;
        $conditions['limit'] = $perPage;
        
        $data['event'] = $this->com_model->getRows($tables,$fields,$cond,$conditions);
       // echo $this->db->last_query();die;
        $this->load->view('admin/client/client_in', $data, false);
    }




	function edit($id="")
	{
	    $data['client']  = $client = $this->my_model->getfields('md_frontuser','*',array('id'=>$id));
		$data['country'] = $this->my_model->fieldResult('md_countries','id,name,phonecode');
		$data['state']   = $this->my_model->getfields('md_states','id,name',array('country_id'=>$client[0]->country_id));
		$data['designation']  = $this->my_model->getfields(DESIGNATION,'id,name',array('status'=>'1'));
		//echo $this->db->last_query();die;
		$data['title']   = COMPANYNAME.' | Edit Client';
		$this->load->view('admin/common/header',$data); 
 		$this->load->view('admin/common/left-sidebar');
		$this->load->view('admin/client/editclient_view');
		$this->footer();
	}

	function editclient()
	{
		$clientid    = $this->input->post('clientid'); 
		$updateDate = array(

                             'firstname'     => $this->input->post('first_name'),
                             'lastname'      => $this->input->post('last_name'),
                             'emailid'       => $this->input->post('email'),
                             'mobile'        => $this->input->post('mobile'),
                             'country_id'    => $this->input->post('country'),
                             'state_id'      => $this->input->post('state'),
                             'city'          => $this->input->post('city'),
                             'pin_code'      => $this->input->post('pincode'),
                             'designation_id'=> $this->input->post('des_name'),
                             'company_name'  => $this->input->post('company_name'),
                             'updated_date'  =>date('Y-m-d h:i:s'),

		                    );
		$update =$this->my_model->update_data('md_frontuser',array('id'=>$clientid),$updateDate);
		if($update)
		{
           $this->msgsuccess("Client Updated successfully..");
           redirect('admin/client');
        }   
       else
       {
       	 $this->msgwarning("Client Not Updated successfully..");
       	 redirect('admin/client');
       }	 
	} 

	public function getstate()
	{
		$country_id = $this->input->post('cont_id');
		$state = $this->my_model->getfields('md_states','id,name',array('country_id'=>$country_id));
		$st = "<select class='form-control form-control-chosen' name='state'>";
		$st .= "<option value=''>Select State</option>";
		foreach($state as $val)
		{
			
			
			$st .= "<option value='$val->id'>".$val->name." </option>";
			
		}
		$st .="</select>";
		echo $st;
	}


	function payment($id="")
	{
		$data['clientPayment']  = $expertid = $this->my_model->getfields(PAYMENT,'*',array('user_id'=>$id));
		//echo $expertid[0]->user_id;die;
		$data['CleintName']   = $this->my_model->fetchValue(USERS,'firstname',array('id'=>$id));
		$data['expertname']   = $this->my_model->fetchValue(USERS,'firstname',array('id'=>$expertid[0]->expert_id,'user_type'=>'2'));
		//echo $this->db->last_query();
        $data['id'] =  $id; 
		$data['title']   = COMPANYNAME.' | Payment History';
		$this->load->view('admin/common/header',$data); 
 		$this->load->view('admin/common/left-sidebar');
		$this->load->view('admin/client/payment_history_view');
		$this->footer();
	}

	function cleintconcerned($id="")
	{
	   $query = "SELECT u.firstname,u.lastname ,u.emailid,u.mobile,em.question_id,em.create_date FROM `md_experts_map` as em INNER JOIN md_experts_connect as ec on ec.id=em.question_id INNER JOIN md_frontuser as u on u.id=em.experts_id WHERE ec.client_id='".$id."' and em.status =1";
		  $data['client'] =  $this->my_model->custom($query); 
		  //echo $this->db->last_query();die;
		  $data['id'] =$id;
		//$data['expert']  = $this->my_model->getfields(USERS,'*',array('id'=>$expert_id,'user_type'=>'2'));
		$data['title']   = COMPANYNAME.' | Cleint With Experts ';
		$this->load->view('admin/common/header',$data); 
 		$this->load->view('admin/common/left-sidebar');
		$this->load->view('admin/client/client_with_expert');
		$this->footer();
	}

	public function deleteAll()
		{
		  $userid = $this->input->post('fieldvalue');
		  $table = strrev($this->input->post('table'));
		  $delete = $this->my_model->deleteRow($table,array('id'=>$userid));
		  if($delete)
		  {
		     $this->my_model->deleteRow('md_experts_connect',array('client_id'=>$userid));
		     $this->msgsuccess("Record has been successfully deleted ");
			 echo 1;
		  	
		  }
		  else
		  {
		  	$this->msgerror("Record deletion failed ");
			echo 0;
		  }
		}

}	

?>
