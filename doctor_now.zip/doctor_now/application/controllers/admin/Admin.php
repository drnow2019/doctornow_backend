<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
ob_start();
class Admin extends MY_Controller {
   	
   	public function __construct()
   	{
	  	parent::__construct();
        $this->load->model('My_model');
        $this->load->model('login_model');
         $this->load->model('user_model');
      
   	}
   	
   	public function index()
   	{  		
		$data['title'] 	= COMPANYNAME.' | Login page';
		$this->load->view("admin/login/login_view",$data);
	}

	public function adminlogin()
	{
		$redirecturl  = "admin/admin";
		$username	  = $this->input->post('username');
		$pass 		  = $this->input->post('password');
		if($username == "") { $this->msgerror('Username is empty'); }
		else if($pass == "") { $this->msgerror('Password is empty'); }
		else {
			$result1=$this->My_model->getfields(ADMIN,"username",array('username'=>$username),"");

		if(!empty($result1)){
				$cond = array ('username' =>$username,'password'=>md5($pass),'status'=>'1');
				$fields = "id,name,username,email";
				$result=$this->My_model->getfields(ADMIN,$fields,$cond,"");
			//echo $this->db->last_query();die;
				if(!empty($result)){
          $roleid = '';
          $menuRole = $this->user_model->getCondResultArray(ROLES,'*',array('staff_id' => $result[0]->id));
         // echo $this->db->last_query();die;
          if($menuRole)
          {
            foreach($menuRole as $role):
             $roleid[$role['menu_id']] = array('add_id'=>$role['add_id'], 'edit_id'=>$role['edit_id'], 'del_id'=>$role['del_id']);
            endforeach;
          }

          $blockarr = array();
          $blockMenu = $this->user_model->getCondResult(MENU,'id,menu_name',array('status !=' => '1'));
          if($blockMenu)
          {
            foreach($blockMenu as $blockrole):
              $blockarr[$blockrole->id] = $blockrole->menu_name;
            endforeach;
          }

          $roleid = array_diff_key($roleid,$blockarr);

					
					$otp=rand('1000000','9999999');
					$userdata = array(
						   'username'  	=> $result[0]->username,
						   'useremail'  => $result[0]->email,
						   'userid'     => $result[0]->id,
						   'permission' => $result[0]->id,
						   'user_type'  =>$result[0]->user_type,
						   'login_otp'  =>$otp,
						   'user_logged_in' => TRUE,
               'roleid1'        =>$roleid,
					   );
			//	echo"<pre>";
///print_r($userdata['roleid1']);die;
					$this->session->set_userdata($userdata);
				
					$redirecturl = "admin/dashboard";
				}
				else { $this->msgerror('Password is incorrect'); }
			}
			else { $this->msgerror('This Username is not registered'); }
		}
	
		redirect($redirecturl);
	
	} ////--- END LOGIN FUNCTION 

   
	
	
	
/////=====	START LOGOUT ======////
	public function logout()
	{
		$this->session->sess_destroy();  
		redirect('admin/admin');
	}
	
	public function changepassword()
   	{

   		
    $data['title'] = COMPANYNAME.' | Change Password';
    $this->load->view('admin/common/header',$data); 
 		$this->load->view('admin/common/left-sidebar');
		$this->load->view('admin/password/changepass_view');
		$this->load->view('admin/common/footer');	

   	} 

   	public function changepass()
   	{
    $userid       = $this->session->userdata('userid');
   	$newPass      =md5($this->input->post('newpwd')); 
   	$oldPass      =md5($this->input->post('oldpwd')); 	
   	$confPass     =md5($this->input->post('conpwd')); 

   	$condition_array = array(
							  'id'        =>  $userid,
							  'password'  =>  $oldPass,
							 );	
     
    if($this->input->post('newpwd')!=$this->input->post('oldpwd'))
    {
   $result = $this->My_model->authenticate(ADMIN,$condition_array);
  if(count($result)==1)
   { 
   	 
   	$data_array=array("password" =>$newPass);
     if($newPass==$confPass)
   	 {
   	 $update =$this->My_model->update_data(ADMIN,$condition_array,$data_array);
      
     $this->msgsuccess("Password update successfully");
     redirect('admin/admin/changepassword');
   	}
   	else
   	{   $this->msgerror('Password Mismatch');
   		
		redirect('admin/admin/changepassword');	
   	}
   }
    else
   {

    		 
    		$this->msgerror('Old Password Worng '); 
		   redirect('admin/admin/changepassword');	
    }
	
	
	
}
else

{
	$this->msgerror('New Password Must Be Diffrent To Old Password'); 
		   redirect('admin/admin/changepassword');	
}

}


function forgotpass()
{
	
  $msg="";	
  //$email ="rachana@finesofttechnologies.com";
  $email = $this->input->post('email');
 
  $con =array('email'=>$email );
  $fields = "id,username,email";
  $user=$this->My_model->getfields(ADMIN,$fields,$con);
 
  
  if(!empty($user)){
   $name         = ucfirst($user[0]->username);
   $email        = $user[0]->email;
   $data['name'] = ucfirst($name);
   $sendcode     = md5($user[0]->username).date("dmYhis");
   $linkurl      = $data['linkurl']=base_url('admin/admin/forgotpassword/'.$sendcode);
 
   $this->My_model->update_data(ADMIN,array('email' =>$email),array('confirm_code'=>$sendcode));
  //echo $this->db->last_query();die;
   $this->load->model('Sendmail');
   $mailmsg='Dear '.$name.'<br><p style ="color:#000;text-align:left;font-family:Arial; line-height:1.6;">We have received a password reset request, please click on below link to reset your password:</p><br>
      <table> 
      <a href="'.$linkurl.'"><strong>CLICK HERE</strong></a><br/>
      </table><br>
      <p style ="color:#000;text-align:left;font-family:Arial; line-height:1.6;">Thanks for Choosing Aria Token!</p><br>
      <p style ="color:#000;text-align:left;font-family:Arial; line-height:1.6;">Sincerely<br/>Aria Token</p>';
  //$mailmsg = $this->load->view('templets/forgetpasswordmail_view',$data,true);
  $this->Sendmail->sendmail($email,"AriaToken Admin Password Reset Request",$mailmsg);
  $msg = " <strong>Success ! </strong> Please check your email. Password reset instructions sent to the associated email address.";
    
    }
    else{ $msg = " <strong>Warning ! </strong> Email id doesn't exist, Please enter a valid Email id"; }
  

    
    
  echo '<div class="alert alert-success alert-dismissable"><a href="#" class="close" data-dismiss="alert" aria-label="close">
        &times;</a>'.$msg.'</div>';	
}

function forgotpassword()
{   
	$data['uri_data'] = $this->uri->segment(4);
	$data['title'] 	  = COMPANYNAME.' | Forgot Password';
	$this->load->view("admin/login/forgot_view",$data);
}


function adminforgotpass()
{   
	$uri_data = $this->input->post("uri_data");
    $new_pass1=$this->input->post("new_pass");
    $con_pass1=$this->input->post("con_pass");
    if($new_pass1 == "" || $con_pass1 == "")  
    { 
      $this->msgwarning("Please fill all input fields");
       redirect('admin/admin/forgotpassword');  
    }   
    if($new_pass1 != $con_pass1)    
    { 
      $this->msgwarning("New password must be equal to confirm password"); 
     redirect('admin/admin/forgotpassword');       
    }

    
    $new_pass=md5($new_pass1);
    $con_pass=md5($con_pass1);

    
      $con=array("confirm_code"=>$uri_data);
      $updatedata=array("password"=>$new_pass);
     
      $update=$this->My_model->update_data(ADMIN,$con,$updatedata);
      if($update) {
     
        $this->msgsuccess("Password has been successfully updated,Please Login here.");           
         redirect('admin/admin/index'); 
   }
}




}
?>

