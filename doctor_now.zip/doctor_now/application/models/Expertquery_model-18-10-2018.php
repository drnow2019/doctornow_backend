<?php
//////------ COMMON MODEL -------/////
class Expertquery_model extends CI_Model
{
	function __construct() 
  {
    /* Call the Model constructor */
    parent::__construct();

  }


public function getRows($params = array())
{
        $this->db->select('u.firstname,f.id,u.user_type,f.expert_id,e.question,f.message');
        $this->db->from(FEEDBACK.' as f');
        $this->db->join(USERS.' as u', 'u.id = f.client_id');
       // $this->db->join(USERS.' as u', 'u.id = f.expert_id');
        $this->db->join(EXPERTQUERY.' as e', 'e.id = f.question_id');
      
          
        
        $cond="f.id>0";
		if(isset($params['search']['keywords'])){
          $keywords = $params['search']['keywords'];
         if($keywords)
           $cond .= " and (firstname LIKE '%".$keywords."%')";
		}

         if(array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit'],$params['start']);
        elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit']);
        $this->db->where($cond);
        $this->db->order_by('f.id','desc');
        $data = $this->db->get();
        return ($data->num_rows() >0)?$data->result():NULL;
}

public function getRowsP($params = array())
{
        $this->db->select('u.firstname as uname,ex.firstname as expertname,p.expert_id,p.payment_method,p.amount,p.transaction_id,e.question,p.status,p.pay_date,p.question_id,p.id');
        $this->db->from(PAYMENT.' as p');
        $this->db->join(USERS.' as u', 'u.id = p.user_id');
        $this->db->join(USERS.' as ex', 'ex.id = p.expert_id');
        $this->db->join(EXPERTQUERY.' as e', 'e.id = p.question_id');
      
          
        
          $cond="p.id>0";
		  
		  if(isset($params['search']['keywords'])){
			$keywords = $params['search']['keywords'];
		  }
		 if(isset($params['search']['date']))
          $date = $params['search']['date'];
		  
		 if(isset($params['search']['status']))
          $status = $params['search']['status'];
         
		 if(isset($status) && $status )
              $cond.=" and p.status = $status";
          if(isset($date) && $date  )
              $cond.= " and $date";
         if(isset($keywords) && $keywords  )
           $cond .= " and (u.firstname LIKE '%".$keywords."%' OR ex.firstname LIKE '%".$keywords."%')";

         if(array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit'],$params['start']);
        elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit']);
        $this->db->where($cond);
        $this->db->order_by('p.id','desc');
        $data = $this->db->get();
        return ($data->num_rows() >0)?$data->result():NULL;
}

 function earningHistory($cond)
 {
        $this->db->select('q.question,e.question_id,e.amount,e.created_date,e.expert_id,u.firstname,u.mobile,u.emailid');
        $this->db->from(EARNING.' as e');
        $this->db->join(USERS.' as u', 'u.id = e.expert_id');
        $this->db->join(EXPERTQUERY.' as q', 'q.id = e.question_id');
        $this->db->where($cond);
        $this->db->order_by('e.id','desc');
        $data = $this->db->get();
        return ($data->num_rows() >0)?$data->result():NULL;
 }

public function getRowsPR($params = array())
{
        $this->db->select('pr.id,ex.firstname as expertname,pr.bank_details_id,pr.request_amount,pr.create_date,pr.status');
        $this->db->from(PAYMENTREQUEST.' as pr');
        $this->db->join(USERS.' as ex', 'ex.id = pr.expert_id');        
        $cond="ex.id>0";
		
		 if(isset($params['search']['keywords'])){
			$keywords = $params['search']['keywords'];
		 }
		 
		 if(isset($params['search']['date']))
			$date = $params['search']['date'];
		  
		 if(isset($params['search']['status']))
          $status = $params['search']['status'];
	  
		 if(isset($status) && $status )
              $cond.=" and pr.status = $status";
          if(isset($date) && $date  )
              $cond.= " and $date";
         if(isset($keywords) && $keywords  )
           $cond .= " and (ex.firstname LIKE '%".$keywords."%')";

         if(array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit'],$params['start']);
        elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit']);
        $this->db->where($cond);
        $this->db->order_by('pr.id','desc');
        $data = $this->db->get();
        return ($data->num_rows() >0)?$data->result():NULL;
}



}