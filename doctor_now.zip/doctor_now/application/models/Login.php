<?php if(!defined('BASEPATH')) exit('Direct access not allowed');

class Login extends CI_Model
	{
	 function __construct()
	{
		parent::__construct();
		
	}

	function username_exists($username)
	{
	    $this->db->where('username',$username);
	    $query = $this->db->get('dav_customers');
	    if ($query->num_rows() > 0){
	        return true;
	    }
	    else{
	        return false;
	    }
	}


	function db_action_perform($table,$data,$action,$condition_arr='')
	{	
	
	if($action == 'insert')
		{
			$this->db->trans_start();
			$this->db->insert($table,$data);
			
			$insert_id = $this->db->insert_id();
			//echo $insert_id;
			$this->db->trans_complete();
			if($this->db->trans_status() === FALSE)
			{
				log_message('error','profile data not inserted in db_action_perform()');
			}
			//echo $this->db->last_query();
			return $insert_id;
			exit();
		}
		if($action == 'update')
		{
			$this->db->trans_start();
			$this->db->where($condition_arr);
			$this->db->update($table,$data);
			$this->db->trans_complete();
			if($this->db->trans_status() === FALSE)
			{
				log_message('error','existing user profile data not update in db_action_perform');
				return false;
				exit();
			}
			return true;
		}
	}
	// function for count record
	public function record_count($query) {
	      
		  $exe= $this->db->query($query);
		$numrows = $exe->num_rows();
		//echo $this->db->last_query();
		return $numrows;
		}
	
		// Fetch data according to per_page limit.
		public function fetch_data($table,$condition,$orderby,$limitS,$limitE) {
		
		if(!$condition){
			if((!$limitS) && (!$limitE))
			    $sql="select * from ".$table." order by ".$orderby;
			else
				$sql="select * from ".$table." order by ".$orderby." limit ".$limitS.", ".$limitE;
		}
		else {
			if((!$limitS) && (!$limitE))
				$sql="select * from ".$table." where ".$condition." order by ".$orderby;
			else
				$sql="select * from ".$table." where ".$condition." order by ".$orderby." limit ".$limitS.", ".$limitE;
		}
		
		$query = $this->db->query($sql);
		$this->db->last_query();
		if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
		$data[] = $row;
		}
		//var_dump($data);
		return $data;
		}
		return false;
		}
		
		function teamdata($id)
		{
		echo $id; exit;

		$query = "SELECT * FROM bis_team  WHERE team_id='".$id."'";

		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
		$records = $result->result_array();
		return $records;
		exit();
		}
		}	
	
		
		
		function fetchdata($table,$id)
		{
		if($id == "")
		{
		$query="select * from ".$table." where 1=1";
		} 
		else {
		
		$query="select * from ".$table." where id='".$id."'"; }
		
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
		}
		
		
		function fetchproductcatdata(){
			
			$query = "select p.id,p.name,p.url,p.cat_id,p.quantity,p.stockstatus,p.rating,p.weight,p.description from dav_products as p left join dav_categories on dav_categories.cat_id = p.id where p.id!='0' && p.is_active='on' group by p.cat_id order by p.id";
			$result = $this->db->query($query);
			if($result->num_rows() > 0){
				$records = $result->result_array();
				return $records;
				exit();
			}
		
		}
		
		function fetchconditiondata($table,$condition)
		{
		if($condition == "")
		{
		  $query="select * from ".$table." where 1=1";
		} 
		else {
		
		    $query="select * from ".$table." where $condition";
		}
		
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
		}

		function fetchconditiondata_row($table,$condition)
		{
		if($condition == "")
		{
		  $query="select * from ".$table." where 1=1";
		} 
		else {
		
		    $query="select * from ".$table." where $condition";
		}
		
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->row();
			return $records;
			exit();
		}
		}
		
		function fetchconditiondata_single($table,$condition)
		{
		if($condition == "")
		{
		  $query="select * from ".$table." where 1=1";
		} 
		else {
		
		    $query="select * from ".$table." where $condition";
		}
		
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
		}
		function fetchconditiondata_both($table,$condition,$textname)
		{
			if($condition == "" || $textname == "")
			{
				$query = "select * from ". $table. "where 1=1";
			}
			else
			{
			    $query = "select * from ".$table ." where $condition and name like '%$textname%'";
			}
			
			$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
			
		}
		function getcategoryid($table,$con)
		{
			if($con =="")
			{
				$query = "select * from ".$table." where 1=1";
			}
			else
			{
				$query   =  "select cat_id from " .$table. " where $con";
			}
			$result =  $this->db->query($query);
			if($result->num_rows () > 0 )
			{
				$records =  $result->result_array();
				return $records;
				exit();
			}
		}
	
		function blogdata()
		{
		 $query="select wp_posts.post_title,wp_posts.post_content,wp_posts.post_name,wp_postmeta.* from wp_posts join wp_postmeta on wp_posts.ID=wp_postmeta.post_id where wp_posts.post_status='publish' order by wp_posts.ID DESC limit 0,6 ";
		
		$result = $this->db2->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
		}
		
	function fetchconditionurl($table,$condition)
		{
		if($condition == "")
		{
		$query="select url from ".$table." where 1=1";
		} 
		else {
		
		$query="select url,cat_name from ".$table." where $condition";
		}
		
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
		}
	// ----- ------- System setting ------- -----	
	function update_to_royal()
	{
		$this->db->select('update_to_royal');
		$this->db->where('id','1');
		$query = $this->db->get(SYSTEMSETTINGS);
		if($query->num_rows() >0)
		{
			return $query->row();
		}
	}	

	function sys_setting_data()
	{
		$this->db->order_by("id", "asc");
		$query = $this->db->get(SYSTEMSETTINGS);
		if($query->num_rows() >0 )
		{
			return $query->result_array();
		}
	}
	
	
	function record_exist($column,$table,$condition)
	{
		$this->db->select($column);
		$this->db->from($table);
		$this->db->where($condition);
		if(!$records = $this->db->get())
		{
			log_message('error','existing user profile data not update in db_action_perform');
			return 'error';exit();
		}
		if($records->num_rows() > 0)
		{
			return '1'; exit();
		}
		return '01'; exit();
	}

    function admindata()
	{
		$query = "SELECT * FROM usrs ";
		$result = $this->db->query($query);
		if($result->num_rows() > 0)
		{
			$records = $result->result_array();
			return $records;
			exit();
		}
    }
	
//--categories data for left sidebar------------------------------------------------------------	
function categoriesdatamodal()
{
$query = "SELECT * FROM dav_categories";
$result = $this->db->query($query);
if($result->num_rows() > 0)
{
$records = $result->result_array();
return $records;
exit();
}
}

//--products data for left sidebar------------------------------------------------------------	
function productsdatamodal()
{
$query = "SELECT * FROM dav_products order by short_order asc limit 0,20";
$result = $this->db->query($query);
if($result->num_rows() > 0)
{
$records = $result->result_array();
return $records;
exit();
}
}

function productsdatamodalfooter()
{
$query = "SELECT * FROM dav_products order by short_order asc limit 0,5";
$result = $this->db->query($query);
if($result->num_rows() > 0)
{
$records = $result->result_array();
return $records;
exit();
}
}

	
	
	
	
	function getclolumvalue($columnname, $table,$condition)
	{
	  $query="Select $columnname From $table where $condition";
	 
	
	
				$result = $this->db->query($query);
				
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
					}
					
		//print_r($records);
		return $records[0][$columnname];
		exit;
	}
	
	function homeproductdata(){
	$con = " and FIND_IN_SET('1',".PRODUCTS.".cat_id)";
	$con .= " and ".PRODUCTS.".year='2013'";
	  $query="select DISTINCT ".PRODUCTS.".name, ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".is_active='on' and ".PRODUCTS.".stockstatus='instock' order by ".PRODUCTS.".id  desc limit 0,6";
	  	$result = $this->db->query($query);
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
						return $records;
						exit();
					}
	}
	
	function allproductdata($url)
	{
	if($url == "")
	{
 $query="select ".PRODUCTS.".name,".PRODUCTS.".year,".PRODUCTS.".sku,  ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".is_active='on' and ".PRODUCTS.".stockstatus='instock' order by ".PRODUCTS.".id  desc";
	}
	else
	{
		 $query="select ".PRODUCTS.".*, ".PRODUCTS.".year, ".PRODUCTS.".sku ,".PRODUCTPRICE.".single_user,".PRODUCTPRICE.".multi_user,".PRODUCTPRICE.".special_price from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".is_active='on' and ".PRODUCTS.".stockstatus='instock' and ".PRODUCTS.".url='$url'"; 
	
		
	}
	$result = $this->db->query($query);
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
						return $records;
						exit();
					}
	
	}
	
	
	function productdata()
	{
	
 $query="select ".PRODUCTS.".name,".PRODUCTS.".year, ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".is_active='on' and ".PRODUCTS.".short_order !='' and ".PRODUCTS.".stockstatus='instock' order by ".PRODUCTS.".short_order  asc";
	
	$result = $this->db->query($query);
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
						return $records;
						exit();
					}
	
	}
	
	
	function productdata21()
	{
 $query="select ".PRODUCTS.".name,".PRODUCTS.".year, ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".short_order !='' and ".PRODUCTS.".stockstatus='instock' order by ".PRODUCTS.".id  desc";

	
	$result = $this->db->query($query);
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
						return $records;
						exit();
					}
	
	}
	
	function loadproductdata($start)
	{
	$start=$start*5;
 $query="select DISTINCT ".PRODUCTS.".name,".PRODUCTS.".year, ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".short_order !='' and ".PRODUCTS.".stockstatus='instock' order by ".PRODUCTS.".id  desc limit ".$start.", 5";

	
	$result=$this->db->query($query);
		if($result->num_rows()>0)
		{
		$result1=$result->result_array();
		return $result1;
		}
		
	}
	
	function productdatacount()
	{
	
 $query="select ".PRODUCTS.".name,".PRODUCTS.".year, ".PRODUCTS.".cat_id,".PRODUCTS.".url,".PRODUCTS.".short_description, ".PRODUCTPRICE.".single_user from ".PRODUCTS." inner join ".PRODUCTPRICE." on ".PRODUCTS.".id =".PRODUCTPRICE.".prod_id where ".PRODUCTS.".short_order !='' * ".PRODUCTS.".stockstatus='instock' ";
$result1=$this->db->query($query)->num_rows();
	return $result1;
	
	}
	
	function searchkeyword($key)
	{
	$val1=str_replace("-"," ",$key);
	 $query="Select * From articles where metakeyword like '%$val1%'";
	
	$result = $this->db->query($query);
					if($result->num_rows() > 0)
					{
						$records = $result->result_array();
						return $records;
						exit();
					}
					
					
	}	
	
	
 
 

	
	function getdata($table, $id='')
	{
	
	if($id!='')
	{
	$con=$id;
	}
	else
	{
	$con="id != 0";
	} 
	
	$query="SELECT * From ".$table." WHERE ".$con;
	
		
	$result = $this->db->query($query);
		
	if($result->num_rows() > 0)
	{
		 $records = $result->result_array();
		
		return $records;
		exit();
	}
	}	
	
	function getrecordcount($table, $count, $condition)
	{
		if($condition!='')
		{
		$con=$condition;
		}
		else
		{
		$con="id != 0";
		}
	
	 $sql= "select $count as total from $table where $con";

	$result = $this->db->query($sql);
		
	if($result->num_rows() > 0)
	{
		 $records = $result->result_array();
	}	
		return $records[0]['total'];
		exit();
	}
	
	
  function searchRes($product,$cat=''){
    if($cat){
    $this->db->select('cat_id')->from(CATEGORIES)->where('url',$cat);
    $catid = $this->db->get()->row()->cat_id;

	$catval = " and FIND_IN_SET('1',cat_id)";
	}
   echo  $sql= "select * from ".PRODUCTS." where 1=1 $catval and name like '%$product%'";
		
	$result = $this->db->query($sql);
		
	if($result->num_rows() > 0)
	{
		 $records = $result->result_array();
		
		return $records;
		exit();
	}
  }
	
	
		
	}
	
?>