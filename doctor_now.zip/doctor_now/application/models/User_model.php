<?php
class User_model extends CI_Model
{
	public function selectCondQry($table,$cond_arr,$orderby,$order,$limitS,$limitE) 
	{
		//return $cond_arr; 
		if(empty($cond_arr) )
		{
			if((!$limitS) && (!$limitE))
			{
				$this->db->from($table);
				$this->db->order_by($orderby,$order);
				$sql = $this->db->get();
			}
			else
			{
				$this->db->from($table);
				$this->db->order_by($orderby,$order);
				$this->db->limit($limitE, $limitS);
				$sql = $this->db->get();
			}
		}
		else
		{
			if((!$limitS) && (!$limitE))
			{	
				
				$this->db->from($table);
				$this->db->where($cond_arr);
				$this->db->order_by($orderby,$order);
				$sql = $this->db->get();
			}  
			else
			{
				
				$this->db->from($table);
				$this->db->where($cond_arr);
				$this->db->order_by($orderby,$order);
				$this->db->limit($limitE, $limitS);
				$sql = $this->db->get();
			}
				
		}
		return ($sql->num_rows() > 0)?$sql->result():FALSE;
	}

	public function selectQry($table,$cond_arr,$limitS,$limitE) 
	{
		if(empty($cond_arr) )
		{
			if((!$limitS) && (!$limitE))
			{
				$this->db->from($table);
				$sql = $this->db->get();
			}
			else
			{
				$this->db->from($table);
				$this->db->limit($limitE, $limitS);
				$sql = $this->db->get();
			}
		}
		else
		{
			if((!$limitS) && (!$limitE))
			{	
				$this->db->where($cond_arr);
				$this->db->from($table);
				$sql = $this->db->get();
			}  
			else
			{
				$this->db->where($cond_arr);
				$this->db->from($table);
				$this->db->limit($limitE, $limitS);
				$sql = $this->db->get();
			}
				
		}
		return ($sql->num_rows() > 0)?$sql->result_array():FALSE;
	}

	public function getAll($table,$cond)
	{
		$this->db->from($table);
		$this->db->where($cond);		
        return $this->db->count_all_results();
 
	}

	public function getCount($table,$field,$cond)
	{
		$this->db->select($field);
		$this->db->from($table);
		$this->db->where($cond);		
        return $this->db->count_all_results();
 
	}

	public function getSum($table,$feilds,$cond)
    {
        $this->db->select_sum($feilds);
        $this->db->from();
        $this->db->where($cond);
        $data = $this->db->get($table);

        return ($data->num_rows() > 0)?$data->row():0;
    } 

	public function maxInvoiceNo()
	{
		$query 	= $this->db->query("SELECT MAX(CAST(SUBSTRING(invoice_no,5) AS UNSIGNED))  as 'invoice_no' FROM ".INVOICE );
		$result = $query->row();
		$invNo 	= $result->invoice_no;
		$invID 	= str_pad(++$invNo, 4, '0', STR_PAD_LEFT);
		return 'IND/'.($invID);
	}

	public function maxSerialNo()
	{
		$query 	= $this->db->query("SELECT MAX(CAST(SUBSTRING(serial_no,1) AS UNSIGNED))  as 'serial_no' FROM ".STOCKSERIAL );
		$result = $query->row();
		$sNO 	= ($result->serial_no)?$result->serial_no:99999;
		return ++$sNO;
	}

	public function checkUser($clientId)
	{
		$this->db->select("admin_id");
		$this->db->where("user_id",$clientId);
        $query = $this->db->get(ADMINLOGIN);

        $this->db->select("id");
		$this->db->where(array('client_id' => $clientId));
        $client = $this->db->get(CLIENT);

        if($query->num_rows() > 0)
      		return TRUE;
      	else 
      		return ($client->num_rows() >0)?TRUE:FALSE;
    }

    public function checkStaffEmail($email)
	{
		$this->db->select("admin_id");
		$this->db->where("emailid",$email);
        $query = $this->db->get(ADMINLOGIN);

		$this->db->select("id");
		$this->db->where("email",$email);
        $client = $this->db->get(CLIENT);

        if($query->num_rows() > 0)
      		return TRUE;
      	else
      	  return ($client->num_rows() >0)?TRUE:FALSE;
    }

    public function checkUserEmail($email)
	{
		$this->db->select("id");
		$this->db->where("email",$email);
        $client = $this->db->get(CLIENT);

      	return ($client->num_rows() >0)?TRUE:FALSE;
    }
    
	public function fetchCondRow($table,$con)
    {
       $data = $this->db
	                ->select('*')
					->from($table)
					->where($con)
					->get();
					
	   	return ($data->num_rows() > 0)?$data->row():FALSE;
	}

	public function fieldCondRow($table,$filed,$con)
    {
       $data = $this->db
	                ->select($filed)
					->from($table)
					->where($con)
					->get();
		//echo 	$data->num_rows();
	  //return ($data->num_rows() > 0)?$data->row():FALSE; 
	  return $data->row();
	}

	public function resultArrayNull($table,$filed,$con)
    {
       $data = $this->db
	                ->select($filed)
					->from($table)
					->where($con)
					->get();
	  return ($data->num_rows() > 0)?$data->result_array():NULL; 
	}

	public function fieldCRow($table,$filed,$con)
    {
       $data = $this->db
	                ->select($filed)
					->from($table)
					->where($con)
					->get();
	  return ($data->num_rows() > 0)?$data->row():FALSE; 
	}

	public function getCondResult($table,$filed,$con)
    {
       $data = $this->db
	                ->select($filed)
					->from($table)
					->where($con)
					->get();
				
	   	return ($data->num_rows() > 0)?$data->result():FALSE;	
	}

	public function getCondResultArray($table,$filed,$con)
    {
       $data = $this->db
	                ->select($filed)
					->from($table)
					->where($con)
					->order_by('menu_id','ASC')
					->get();
					
	   	return ($data->num_rows() > 0)?$data->result_array():FALSE;
	}

	public function getPaymentCount($wCond,$NwCond)
    {
        $this->db->select('count(id) as payid');
        $this->db->where($wCond);
        $this->db->where_not_in('mode', $NwCond);
        $query = $this->db->get(PAYMENT);
        $result = $query->row();
        return ($query->num_rows() > 0)?$result->payid:FALSE;
    }

    public function getPaymentData($wCond,$NwCond)
    {
        $this->db->select('tot_amt,pay_amt,bal_amt,bounce,check_no,client_id');
        $this->db->where($wCond);
        $this->db->where_not_in('mode', $NwCond);
        $this->db->order_by('id','DESC');
        $query = $this->db->get(PAYMENT);
        
        return ($query->num_rows() > 0)?$query->row():FALSE;
    }

	public function fetchValue($table,$field,$con)
    {
       $data = $this->db
	                ->select($field)
					->from($table)
					->where($con)
					->get();
		$result = $data->row();
	   	return ($data->num_rows() >0)?$result->$field:FALSE;
	}

	public function mysqlResult($table,$field,$condition,$orderby,$order)
	{
		$this->db->select($field);
		if($condition)
		   $this->db->where($condition);
		if(!empty($orderby) && !empty($order))
			$this->db->order_by($orderby,$order);
		$query = $this->db->get($table);

		return ($query->num_rows() > 0)?$query->result():FALSE;
	}

	public function mysqlResultLimit($table,$field,$condition,$orderby,$order,$limit,$limitS)
	{
		$this->db->select($field);
		if($condition)
		   $this->db->where($condition);
		if(!empty($orderby) && !empty($order))
			$this->db->order_by($orderby,$order);
		if(!empty($limitS) && !empty($limit))
			$this->db->limit($limit, $limitS);
		else if(empty($limitS) && !empty($limit))
			$this->db->limit($limit);
		$query = $this->db->get($table);

		return ($query->num_rows() > 0)?$query->result():FALSE;
	}

	public function maxIdVal($table,$field)
    {
        $this->db->select($field);
        $data = $this->db->get($table);
        return ($data->num_rows() >0)?$data->row():FALSE;
    }

    public function selectMax($table,$field)
    {
    	$this->db->select_max($field);
    	$data = $this->db->get($table);
    	$dataVal = $data->row();
    	return $dataVal->$field;
    }

    public function selectMaxCond($table,$field,$cond)
    {
    	$this->db->select_max($field);
    	$this->db->where($cond);
    	$data = $this->db->get($table);
    	$dataVal = $data->row();
    	return $dataVal->$field;
    }

    public function maxConVal($table,$field,$cond)
    {
        $this->db->select($field);
        $this->db->where($cond);
        $data = $this->db->get($table);
        return ($data->num_rows() >0)?$data->row():FALSE;
    }

    public function mysqlNumRows($table,$field,$cond)
    {
        $this->db->select($field);
        $this->db->where($cond);
        $data = $this->db->get($table);
        return ($data->num_rows() >0)?$data->num_rows():0;
    }

	public function checkUserExist($table,$con)
    {
       $data = $this->db
	                ->select('*')
					->from($table)
					->where($con)
					->get();
					
	   	return ($data->num_rows() > 0)?TRUE:FALSE;
	}

	public function checkExist($table,$field,$con)
    {
       $data = $this->db
	                ->select($field)
					->from($table)
					->where($con)
					->get();
					
	   	return ($data->num_rows() > 0)?TRUE:FALSE;
	}

	public function getServices()
	{
		$this->db->select('id,service_name,service_validity_id');
        $this->db->from(SERVICES);
        $this->db->where(array('status' => '1'));
        $services = $this->db->get();
        return ($services->num_rows() > 0)?$services->result():FALSE;
	}
	
	public function whereIn($tbl,$field,$con)
    {
	    $data = $this->db
	               ->select($field)
				   ->from($tbl)
				   ->where_in($con)
				   ->get();
		return $data->result();
		//return $this->db->last_query();
    }

    public function whereInResult($tbl,$field,$column,$array)
    {
	    $data = $this->db
	               ->select($field)
				   ->from($tbl)
				   ->where_in($column,$array)
				   ->get();

		return ($data->num_rows() > 0)?$data->result_array():FALSE;
    }

	public function getServiceVal()
	{
		$this->db->select('id,validity_name');
        $this->db->from(SERVICEVALIDITY);
        $servalidity = $this->db->get();
        return ($servalidity->num_rows() > 0)?$servalidity->result():FALSE;
	}

	public function authenticate($tbl,$condition)
    {
		$q = $this->db
		      ->select('*')
			  ->from($tbl)
			  ->where($condition)
			  ->get();
			  return $q->result();
	}
   
   public function insert_data($tbl,$data)
   {
        $this->db->insert($tbl,$data);
		$insert_id = $this->db->insert_id();
		$this->db->cache_delete_all();
		return $insert_id;
   }

   public function soap_api($array)
   {
   		$clientid  = $array['clientid'];  

		$startdate = $array['startdate']; 
		$acc_cid   = $array['acc_cid']; 
		$type 	   = $array['type'];
		$noofrech  = $array['noofrech'];

		$soapUid = SOAPUID;
		$soapUpass = SOAPUPASS;		

		if($type==1)
		{
			$soapUid 	= SOAPUID;
			$soapUpass  = SOAPUPASS;
			$soapapi    = SOAPAPI;
		}
		else if($type==2)
		{
			$soapUid 	= SOAPUIDTWO;
			$soapUpass 	= SOAPUPASSTWO;
			$soapapi    = SOAPAPITWO;
		}
		else
		{
			return;
		}

		$url = base_url('soapapi/index'); 

			$csrf = array(
				'name' => $this->security->get_csrf_token_name(),
				'hash' => $this->security->get_csrf_hash()
			);

			$postData = array(
					'clientid'    => $clientid, 
					$csrf['name'] => $csrf['hash'],
					'soapuname'   => $soapUid,
					'soapupass'   => $soapUpass,
					'soapapi' 	  => $soapapi,
					'startdate'   => $startdate,
					'acc_cid' 	  => $acc_cid,
					'noofrech' 	  => $noofrech 
				);

		$ch = curl_init();   
		curl_setopt($ch, CURLOPT_URL,$url);
		
		curl_setopt($ch, CURLOPT_POST, true);  
		curl_setopt($ch, CURLOPT_POSTFIELDS, urldecode(http_build_query($postData)));     
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);	 
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		$output = curl_exec($ch);	
		curl_close($ch);
		return $output;
	}

	public function sync_date($array)
    {
		$acc_cid   = $array['acc_cid']; 
		$type 	   = $array['server_type'];	

		if($type==1)
		{
			$soapUid 	= SOAPUID;
			$soapUpass  = SOAPUPASS;
			$soapapi    = SOAPAPI;
		}
		else if($type==2)
		{
			$soapUid 	= SOAPUIDTWO;
			$soapUpass 	= SOAPUPASSTWO;
			$soapapi    = SOAPAPITWO;
		}
		else
			return;

		$url = base_url('soapapi/syncDate'); 

		$csrf = array(
			'name' => $this->security->get_csrf_token_name(),
			'hash' => $this->security->get_csrf_hash()
		);

		$postData = array(d, 
				$csrf['name'] => $csrf['hash'],
				'soapuname'   => $soapUid,
				'soapupass'   => $soapUpass,
				'soapapi' 	  => $soapapi,
				'acc_cid' 	  => $acc_cid,
			);

		$ch = curl_init();   
		curl_setopt($ch, CURLOPT_URL,$url);
		
		curl_setopt($ch, CURLOPT_POST, true);  
		curl_setopt($ch, CURLOPT_POSTFIELDS, urldecode(http_build_query($postData)));     
		curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);	 
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		$output = curl_exec($ch);	
		curl_close($ch);
		return $output;
	}

    public function update_data($tbl,$data,$condition)
    {
   		$this->db->trans_start();
   		$this->db->where($condition);
        $this->db->update($tbl,$data);
        $this->db->trans_complete();
        $this->db->cache_delete_all();

		if ($this->db->affected_rows() == '1') 
		    return TRUE;
		else {
		    if ($this->db->trans_status() === FALSE)
		        return FALSE;
		    return TRUE;
		}
    }

	public function update_data_cache($tbl,$data,$condition)
    {
   		$this->db->trans_start();
   		$this->db->where($condition);
        $this->db->update($tbl,$data);
        $this->db->trans_complete();
        $this->db->cache_delete_all();
		if ($this->db->affected_rows() == '1') 
		    return TRUE;
		else {
		    if ($this->db->trans_status() === FALSE)
		        return FALSE;
		    return TRUE;
		}
    }
   
    public function deleteRow($table,$cond)
    {
  		$this->db->where($cond);
  		$this->db->delete($table);
  		$this->db->cache_delete_all();
  		return TRUE;
    }

    public function fetchAllRecords($school)
    {
       $data = $this->db
	                ->select('*')
					->from($school)
					->get();
					//return $data->result();
	   return ($data->num_rows() > 0)?$data->result():FALSE;					
    }
   
    public function getRows($params = array())
    {
     
        $this->db->select('*');
        $this->db->from('isp_adminlogin');
        //filter data by searched keywords
        if(!empty($params['search']['keywords'])){
            $this->db->like('name',$params['search']['keywords']);            
        }
        //sort data by ascending or desceding order
        $this->db->order_by('admin_id','desc');
     
        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit'],$params['start']);
        }elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params)){
            $this->db->limit($params['limit']);
        }
        //get records
        $query = $this->db->get();
        //return fetched data
        return ($query->num_rows() > 0)?$query->result():FALSE;
    }

   public function update_tbl_data($tbl,$con,$data_array)
   {
      return $this->db
	             ->where($con)
				 ->update($tbl,$data_array);
				 //return $this->db->last_query();
   }
   
   
 	public function getArea()
    {
        $this->db->select('id,area_name');
        $this->db->from(AREA);
        $query = $this->db->get();

        return ($query->num_rows() > 0)?$query->result():FALSE;
    }

    public function getBox()
    {
        $this->db->select('id,box_name');
        $this->db->from(BOX);
        $query = $this->db->get();

        return ($query->num_rows() > 0)?$query->result():FALSE;
    }
     public function logactivity($data)
   {
        $this->db->insert(ACTIVITYLOG,$data);
		$insert_id = $this->db->insert_id();
		return $insert_id;
   }


  
}


