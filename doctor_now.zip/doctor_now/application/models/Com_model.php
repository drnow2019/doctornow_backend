<?php
class Com_model extends CI_Model
{   
    public function getRows($tables,$fields,$cond,$params = array())
    {     
		$this->db->cache_on();
		$this->db->cache_off();
        $this->db->select($fields);
        $this->db->from($tables);
        if($cond != ""):
			$this->db->where($cond);
		endif;
        //sort data by ascending or desceding order
        $this->db->order_by('id','desc');

        //set start and limit
        if(array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit'],$params['start']);
        elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit']);
        
        //get records
        $query = $this->db->get();
		$this->db->cache_off();
		//echo $this->db->last_query();
        //return fetched data
        return ($query->num_rows() > 0)?$query->result():NULL;
    }
	

    
	public function cuntrows($tables,$fields,$cond)
    {     
        $this->db->select($fields);
        $this->db->from($tables);
        if($cond != ""):
			$this->db->where($cond);
		endif;
        //sort data by ascending or desceding order
        $this->db->order_by('id','desc');

        //set start and limit
       /*  if(array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit'],$params['start']);
        elseif(!array_key_exists("start",$params) && array_key_exists("limit",$params))
            $this->db->limit($params['limit']);
         */
        //get records
        $query = $this->db->get();
		//echo $this->db->last_query();
        //return fetched data
        return ($query->num_rows() > 0)?$query->num_rows():NULL;
    }
	
	
}

?>