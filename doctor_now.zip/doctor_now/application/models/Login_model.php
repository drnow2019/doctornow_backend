<?php
class Login_model extends CI_Model
{

    public function authenticate($tbl,$condition)
    {
		$q = $this->db
			  ->where($condition)
			  ->get($tbl);
			  return $q->row();
	}

	public function getServer($tbl,$field,$in)
    {

      	$data = $this->db
	               ->select($field)
				   ->from($tbl)
				   ->where('status', '1')
				   ->where_in('id',$in)
				   ->get();

	 	return ($data->num_rows() >0)?$data->result():NULL;
    }
 
  
}

