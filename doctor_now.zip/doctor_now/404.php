  <?php $this->load->view('web/common/header');  ?>
 <div class="container" style="padding:0px;">
  <div class="profile_search" style="background:#fbfbfb">
  	<div class="container wrap_1" style="padding-top:65px;padding-bottom:10px;" align="center">
   <img src="<? echo base_url(); ?>assets/web/images/7108593764127086655.jpg"  alt="">
	 
    </div>
  </div>
    <div class="" style="border:1px solid #f0efef; background:#FFFFFF;">
  <div class="col-md-12" style="background:#fff;"><!--box-shadow:0 8px 6px -9px #333-->
 
  </div>
 
<div class="grid_2" style="background:#fff;padding-bottom:20px; padding-top:10px;border-top:1px solid #f4f4f4">

<div class="breadcrumb1" st>
     <ul>
        <a href="<? echo base_url(); ?>index" style="color:#ef4938;">Home</a>
        <span class="divider">&nbsp;>&nbsp;</span>
        
        <li class="current-page"><b>404 </b></li>
     </ul>
   </div>
	</div>

		  <div class="col-md-8 suceess_story" style="background:#fff;">
		 <h3 style="padding-left:15px;color:#000000;">All Categories</h3>
		<div class="suceess_story-content-container">
	      
		
<img src="<? echo base_url(); ?>assets/img/404-image.png" style="width:100%; height:100%;" />
	            
               
          
          </div>
	    </div>
	    <?php $this->load->view('web/common/rightbar');  ?>

          
              
	     <div class="clearfix"> </div>
	   
  </div>
  
  
   <div class="clearfix"> </div>
	   </div> 
    		
		
		
       
   </div>
  
  
  
  

        <div class="col-md-12" align="center">
        <div class="container">
           <!-- <img src="<? echo base_url(); ?>assets/web/images/ad2.jpg" >-->
            </div>
            </div>  
        
        
        
	    
	 
    </div>
	
	
	
	
  <?php $this->load->view('web/common/footer');  ?>