	<div class="usersactvs">
										    <?php foreach($user as $list){ ?>
											<div class="userinfo">
												<div class="userpic">
												   
												    <?php if($list->image){?>
													<img src="<?= $list->image ?>" title="<?= ucwords($list->name)?>">
													<?php } else {?>
													<img src="<?= base_url('assets/images/avtar_dummy.png')?>" title="No Profile" />
													<?php } ?>
												</div>
											 <a href="">
												<div class="usrcrednt">
													<h6><?= ucwords($list->name) ?></h6>
													<p>Loren ispsum sit amir...</p>
													<p class="statusdrn"><span class="gnblb">Active</span></p>
													<p class="pstdrn">2 day Ago11</p>
													</a>	
												</div>
												
											</div>
											<?php }?>
											
										
											</div>